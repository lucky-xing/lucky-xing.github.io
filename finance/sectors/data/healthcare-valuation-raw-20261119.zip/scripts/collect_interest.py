import requests,json,concurrent.futures
from collect_companies import universe,P
def one(item):
 code=item[0]
 try:
  p={'reportName':'RPT_F10_FINANCE_GINCOME','columns':'SECURITY_CODE,REPORT_DATE,NOTICE_DATE,FE_INTEREST_EXPENSE,INCOME_TAX,TOTAL_PROFIT','pageSize':20,'filter':f'(SECURITY_CODE="{code}")(REPORT_DATE>=\'2025-09-30\')','sortColumns':'REPORT_DATE','sortTypes':'-1'}
  j=requests.get('https://datacenter-web.eastmoney.com/api/data/v1/get',params=p,timeout=35).json();(P/f'{code}-interest.json').write_text(json.dumps(j),encoding='utf-8');r=j['result']['data']
  def at(d):return next(x for x in r if x['REPORT_DATE'].startswith(d))
  v=at('2025-12-31')['FE_INTEREST_EXPENSE']+at('2026-09-30')['FE_INTEREST_EXPENSE']-at('2025-09-30')['FE_INTEREST_EXPENSE']
  return {'code':code,'interest':v}
 except Exception as e:return {'code':code,'interest':None,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(one,universe))
(P/'interest.json').write_text(json.dumps(rows),encoding='utf-8');print(rows)
