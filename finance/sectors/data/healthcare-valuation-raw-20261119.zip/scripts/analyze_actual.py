from pathlib import Path
import json,statistics,math,datetime
P=Path(__file__).parent/'valuation'
CUTOFF='2026-11-18'
def window(rows,key,current,years):
 start=f'{2026-years}-11-18';v=[r[key] for r in rows if r['date']>=start and r['date']<=CUTOFF and r.get(key) is not None and math.isfinite(r[key])]
 rs=[r for r in rows if r['date']>=start and r['date']<=CUTOFF and r.get(key) is not None and math.isfinite(r[key])]
 if not v:return None
 a=sorted(v)
 return {'years':years,'start':rs[0]['date'],'end':rs[-1]['date'],'n':len(v),'pct':sum(x<=current for x in v)/len(v)*100,'q20':a[max(0,math.ceil(.2*len(a))-1)],'median':statistics.median(a),'q80':a[max(0,math.ceil(.8*len(a))-1)],'fullWindow':(datetime.date.fromisoformat(rs[0]['date'])-datetime.date.fromisoformat(start)).days<=45 and len(v)>=years*12-1}
indices=[]
for code,name in [('000933','中证医药卫生'),('000991','全指医药'),('930641','中证中药'),('931152','创新药产业'),('H30217','医疗器械'),('399989','中证医疗')]:
 j=json.loads((P/f'{code}-history.json').read_text(encoding='utf-8'));rows=j['rows'];out={'code':code,'name':name,'source':j['source'],'last':rows[-1],'metrics':{}}
 for key in ['equalWeightedPeTtm','equalWeightedPbTtm']:
  cur=rows[-1][key]; out['metrics'][key]={'current':cur,'windows':[window(rows,key,cur,y) for y in [3,5,10]]}
 indices.append(out)
stocks=json.loads((P/'companies.json').read_text(encoding='utf-8'))
for s in stocks:
 code=s['code'];main=json.loads((P/f'{code}-long-RPT_F10_FINANCE_MAINFINADATA.json').read_text(encoding='utf-8'))['result']['data'];cash=json.loads((P/f'{code}-long-RPT_F10_FINANCE_GCASHFLOW.json').read_text(encoding='utf-8'))['result']['data'];sym=('sh' if code.startswith('6') else 'sz')+code
 monthly=json.loads((P/f'{code}-month.json').read_text(encoding='utf-8'))['data'][sym]['month'];hist=[]
 for quote in monthly:
  date=quote[0]
  pub=[r for r in main if r['NOTICE_DATE'][:10]<date]
  pc=[r for r in cash if r['NOTICE_DATE'][:10]<date]
  if not pub:continue
  f=pub[0];period=f['REPORT_DATE'][:10];yr=int(period[:4])
  def find(rows,d):return next((x for x in rows if x['REPORT_DATE'].startswith(d)),None)
  def ttm(rows,key):
   cur=find(rows,period)
   if not cur:return None
   if period.endswith('12-31'):return cur[key]
   ann=find(rows,f'{yr-1}-12-31');prior=find(rows,str(yr-1)+period[4:])
   if not ann or not prior or any(x.get(key) is None for x in [cur,ann,prior]):return None
   return cur[key]+ann[key]-prior[key]
  ocf=ttm(pc,'NETCASH_OPERATE');capex=ttm(pc,'CONSTRUCT_LONG_ASSET');core=ttm(pub,'KCFJCXSYJLR');cap=float(quote[2])*f['TOTAL_SHARE']
  if ocf is None or capex is None or core is None or not cap:continue
  hist.append({'date':date,'price':float(quote[2]),'cap':cap,'fcf':ocf-capex,'core':core,'fcfYield':(ocf-capex)/cap*100,'corePe':cap/core if core>0 else None,'period':period,'notice':f['NOTICE_DATE'][:10]})
 s['history']=hist;s['windows']={k:[window(hist,k,s[k],y) for y in [3,5,10]] for k in ['fcfYield','corePe'] if s.get(k) is not None}
groups=[]
foreign=json.loads((P/'overseas.json').read_text(encoding='utf-8'))
for r in foreign:
 assert r['quoteTime'] and 'Nov 18' in r['quoteTime'],r
 r['calculatedFcf']=r['ocf']-abs(r['capex']);r['calculatedYield']=r['calculatedFcf']/r['cap']*100;r['calculatedPfcf']=r['cap']/r['calculatedFcf'] if r['calculatedFcf']>0 else None
for group,peer in [('中药','消费健康'),('器械','器械'),('CXO','CXO'),('创新药','成熟制药')]:
 ss=[x for x in stocks if x['group']==group];ff=[x for x in foreign if x['group']==peer];cap=sum(x['cap'] for x in ss);fcf=sum(x['fcf'] for x in ss);core=sum(x['core'] for x in ss)
 g={'group':group,'members':[x['code'] for x in ss],'cap':cap,'fcf':fcf,'fcfYield':fcf/cap*100,'corePe':cap/core,'peerGroup':peer,'peerN':len(ff),'peerMedianYield':statistics.median(x['calculatedYield'] for x in ff),'peerMedianPfcf':statistics.median(x['calculatedPfcf'] for x in ff),'peerTickers':[x['ticker'] for x in ff]}
 g['pfcf']=cap/fcf if fcf>0 else None;g['premiumVsPeerMedian']= (g['pfcf']/g['peerMedianPfcf']-1)*100;g['overseasExpensivenessPct']=sum(x['calculatedYield']>=g['fcfYield'] for x in ff)/len(ff)*100
 dates=sorted(set(x['date'] for x in ss[0]['history']).intersection(*(set(x['date'] for x in s['history']) for s in ss[1:])))
 hist=[]
 for d in dates:
  rr=[next(x for x in s['history'] if x['date']==d) for s in ss];c=sum(x['cap'] for x in rr);f=sum(x['fcf'] for x in rr);co=sum(x['core'] for x in rr)
  hist.append({'date':d,'fcfYield':f/c*100,'corePe':c/co if co>0 else None})
 g['history']=hist;g['windows']={k:[window(hist,k,g[k],y) for y in [3,5,10]] for k in ['fcfYield','corePe']};groups.append(g)
out={'cutoff':CUTOFF,'indices':indices,'stocks':stocks,'overseas':foreign,'groups':groups,'note':'Index vendor equal-weight PE/PB. Company panels fixed current survivors; historical monthly raw quotes and financial statements published before quote; restated data and quarterly shares; no trading backtest. FCF=operating cash less purchases of long-lived assets; not pure FCFE/FCFF.'}
(P/'actual-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
for i in indices:print(i['name'],i['metrics'])
for g in groups:print(json.dumps({k:v for k,v in g.items() if k!='history'},ensure_ascii=False))
