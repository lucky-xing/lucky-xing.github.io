from pathlib import Path
import requests,json,re,concurrent.futures
from bs4 import BeautifulSoup
P=Path(__file__).parent/'valuation'
tasks=[('mdt','器械'),('syk','器械'),('bdx','器械'),('iqv','CXO'),('crl','CXO'),('iclr','CXO'),('mrk','成熟制药'),('nvs','成熟制药'),('azn','成熟制药'),('prgo','消费健康'),('hln','消费健康')]
def one(task):
 ticker,group=task
 try:
  url=f'https://stockanalysis.com/stocks/{ticker}/statistics/';r=requests.get(url,timeout=35);r.raise_for_status();(P/f'us-{ticker}.html').write_bytes(r.content)
  soup=BeautifulSoup(r.content,'html.parser');d={}
  for tr in soup.select('table tr'):
   cells=tr.find_all(['td','th']);
   if len(cells)==2:d[cells[0].get_text(' ',strip=True)]=cells[1].get_text(' ',strip=True)
  txt=soup.get_text(' ',strip=True);m=re.search(r'(Nov 18, 2026, 4:00 PM (?:EST|EDT))',txt)
  def val(key):
   v=d.get(key,'n/a').replace(',','').replace('$','').replace('%','')
   if v in ['n/a','-','—']:return None
   mul={'B':1e9,'M':1e6,'K':1e3}.get(v[-1:],1)
   return float(v[:-1] if mul!=1 else v)*mul
  return {'ticker':ticker.upper(),'group':group,'source':url,'quoteTime':m[1] if m else None,'cap':val('Market Cap'),'ev':val('Enterprise Value'),'ocf':val('Operating Cash Flow'),'capex':val('Capital Expenditures'),'fcf':val('Free Cash Flow'),'pfcf':val('P/FCF Ratio'),'pe':val('PE Ratio'),'forwardPe':val('Forward PE'),'evEbit':val('EV / EBIT'),'evEbitda':val('EV / EBITDA'),'fcfYield':val('FCF Yield'),'data':d}
 except Exception as e:return {'ticker':ticker,'error':str(e)}
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(one,tasks))
 (P/'overseas.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
 for r in rows:print(json.dumps({k:v for k,v in r.items() if k!='data'},ensure_ascii=False))
