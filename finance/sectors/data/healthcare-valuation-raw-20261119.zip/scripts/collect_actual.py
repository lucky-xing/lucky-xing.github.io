from pathlib import Path
import requests,json,re,concurrent.futures
P=Path(__file__).parent/'valuation';P.mkdir(exist_ok=True)
def index(task):
 market,code=task
 u=f'https://www.etf.run/index/{market}/{code}'
 r=requests.get(u,timeout=50);r.raise_for_status();s=r.content.decode('utf-8');(P/f'{code}.html').write_text(s,encoding='utf-8')
 chunks=[json.loads(x) for x in re.findall(r'self\.__next_f\.push\(\[1,("(?:[^"\\]|\\.)*")\]\)',s)]
 t=''.join(chunks); marker='"compressedIndexDaily":'; i=t.find(marker)
 if i<0:return code,'no data'
 obj,_=json.JSONDecoder().raw_decode(t[i+len(marker):]); rows=[dict(zip(obj['fieldNames'],v)) for v in obj['values']]
 rows=[r for r in rows if r['date']<='2026-11-18']
 (P/f'{code}-history.json').write_text(json.dumps({'source':u,'rows':rows},ensure_ascii=False),encoding='utf-8')
 return code,len(rows),rows[-1]
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
  for f in ex.map(index,[('CSI','000933'),('CSI','930641'),('CSI','931152'),('CSI','H30217'),('SZSE','399989'),('CNI','980120')]):print(f,flush=True)
