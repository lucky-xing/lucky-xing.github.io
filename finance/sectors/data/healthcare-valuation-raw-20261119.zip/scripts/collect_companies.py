from pathlib import Path
import requests,json,concurrent.futures
P=Path(__file__).parent/'valuation'
universe=[('000538','云南白药','中药'),('600436','片仔癀','中药'),('000999','华润三九','中药'),('300760','迈瑞医疗','器械'),('688271','联影医疗','器械'),('002223','鱼跃医疗','器械'),('603259','药明康德','CXO'),('300759','康龙化成','CXO'),('300347','泰格医药','CXO'),('600276','恒瑞医药','创新药'),('002422','科伦药业','创新药'),('688235','百济神州','创新药')]
def get(code,report):
 p={'reportName':report,'columns':'ALL','pageSize':100,'filter':f'(SECURITY_CODE="{code}")(REPORT_DATE>=\'2024-09-30\')','sortColumns':'REPORT_DATE','sortTypes':'-1'}
 r=requests.get('https://datacenter-web.eastmoney.com/api/data/v1/get',params=p,timeout=35);r.raise_for_status();j=r.json();(P/f'{code}-{report}.json').write_text(json.dumps(j,ensure_ascii=False),encoding='utf-8');return j['result']['data']
def one(item):
 code,name,group=item
 try:
  main=get(code,'RPT_F10_FINANCE_MAINFINADATA');cash=get(code,'RPT_F10_FINANCE_GCASHFLOW')
  secid=('1.' if code.startswith('6') else '0.')+code
  u='https://web.ifzq.gtimg.cn/appstock/app/fqkline/get'
  q=requests.get(u,params={'param':f'{"sh" if code.startswith("6") else "sz"}{code},day,2026-11-01,2026-11-18,30,'},timeout=30).json()
  (P/f'{code}-quote.json').write_text(json.dumps(q),encoding='utf-8')
  qrows=q['data'][('sh' if code.startswith('6') else 'sz')+code]['day']; row=[x for x in qrows if x[0]=='2026-11-18'][-1];price=float(row[2])
  def at(rows,d):return next(x for x in rows if x['REPORT_DATE'].startswith(d))
  def ttm(rows,k):return at(rows,'2025-12-31')[k]+at(rows,'2026-09-30')[k]-at(rows,'2025-09-30')[k]
  f=at(main,'2026-09-30'); cap=price*f['TOTAL_SHARE'];ocf=ttm(cash,'NETCASH_OPERATE');capex=ttm(cash,'CONSTRUCT_LONG_ASSET');fcf=ocf-capex;profit=ttm(main,'PARENTNETPROFIT');core=ttm(main,'KCFJCXSYJLR');sales=ttm(main,'TOTALOPERATEREVE')
  out={'code':code,'name':name,'group':group,'price':price,'priceDate':row[0],'sharesDate':'2026-09-30','shares':f['TOTAL_SHARE'],'cap':cap,'ocf':ocf,'capex':capex,'fcf':fcf,'profit':profit,'core':core,'revenue':sales,'pe':cap/profit if profit>0 else None,'corePe':cap/core if core>0 else None,'fcfYield':fcf/cap*100,'pfcf':cap/fcf if fcf>0 else None,'cashConversion':ocf/core if core>0 else None,'profitGrowth':f['PARENTNETPROFITTZ'],'coreGrowth':f['KCFJCXSYJLRTZ'],'revenueGrowth':f['TOTALOPERATEREVETZ'],'notice':f['NOTICE_DATE'],'currency':'CNY','periods':['2025-12-31','2026-09-30','2025-09-30']}
  return out
 except Exception as e:return {'code':code,'name':name,'error':str(e)}
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
  rows=list(ex.map(one,universe))
 (P/'companies.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
 for r in rows:print(json.dumps(r,ensure_ascii=False),flush=True)
