import json,requests,concurrent.futures
from pathlib import Path
from collect_companies import universe,P
def one(item):
 code,name,group=item
 try:
  for report,cols in [('RPT_F10_FINANCE_MAINFINADATA','SECURITY_CODE,REPORT_DATE,NOTICE_DATE,TOTAL_SHARE,PARENTNETPROFIT,KCFJCXSYJLR'),('RPT_F10_FINANCE_GCASHFLOW','SECURITY_CODE,REPORT_DATE,NOTICE_DATE,NETCASH_OPERATE,CONSTRUCT_LONG_ASSET')]:
   p={'reportName':report,'columns':cols,'pageSize':200,'filter':f'(SECURITY_CODE="{code}")(REPORT_DATE>=\'2014-09-30\')','sortColumns':'REPORT_DATE','sortTypes':'-1'}
   r=requests.get('https://datacenter-web.eastmoney.com/api/data/v1/get',params=p,timeout=45);r.raise_for_status();j=r.json();assert j.get('result'),j
   (P/f'{code}-long-{report}.json').write_text(json.dumps(j,ensure_ascii=False),encoding='utf-8')
  symbol=('sh' if code.startswith('6') else 'sz')+code
  q=requests.get('https://web.ifzq.gtimg.cn/appstock/app/fqkline/get',params={'param':f'{symbol},month,2015-01-01,2026-11-18,200,'},timeout=35).json()
  (P/f'{code}-month.json').write_text(json.dumps(q),encoding='utf-8')
  return code,len(q['data'][symbol]['month'])
 except Exception as e:return code,str(e)
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
  for r in ex.map(one,universe):print(r,flush=True)
