from pathlib import Path
from bs4 import BeautifulSoup
import shutil,json,zipfile
ROOT=Path(r'D:\codex\2026-11-19\etf')
O=ROOT/'outputs/global100'
SITE=Path(r'D:\codex\2026-10-19\i\work\report-site')
slug='ftse-sp-nasdaq-100-2026-11.html'
s=BeautifulSoup((O/slug).read_text(encoding='utf-8'),'html.parser')
ids=[x['id'] for x in s.select('[id]')]
missing=[a['href'] for a in s.find_all('a',href=True) if a['href'].startswith('#') and a['href'][1:] not in ids]
assert not missing,missing
assert len(ids)==len(set(ids))
assert len(s.select('section'))==17
assert len(s.select('svg'))==4
data=SITE/'finance/sectors/data/global100-20261121'
data.mkdir(parents=True,exist_ok=True)
for name in ['calculations.json','sources.json','研究数据与脚本.zip']:shutil.copy2(O/name,data/name)
shutil.copy2(ROOT/'work/global100/extension/extension-calculations.json',data/'extension-calculations.json')
shutil.copy2(O/slug,SITE/'finance/sectors'/slug)
gallery=SITE/'finance/sectors/xiaohongshu/global100-20261121'
shutil.copytree(O/'xiaohongshu',gallery,dirs_exist_ok=True)
idx=SITE/'finance/sectors/index.html';t=idx.read_text(encoding='utf-8')
if slug not in t:
 t=t.replace('11 篇报告','12 篇报告')
 entry='''<div class="company-list"><article class="company-entry"><div><span class="company-ticker">GLOBAL 100 · VALUATION · ETF</span><time datetime="2026-11-21">2026-11-21</time></div><h2><a href="ftse-sp-nasdaq-100-2026-11.html">富时100、标普100与纳斯达克100：估值、分散与ETF选择 <span>↗</span></a></h2><p>实算估值、年末历史参照、9个成熟市场对照、12家公司财务代理及ETF持仓重叠；附10张小红书图文与数据脚本。</p><strong>富时相对便宜但自身未处低位；纳指需要现金流兑现，标普100与纳指加权重叠55.05%。境内工具先防高溢价。</strong></article></div>'''
 t=t.replace('<div class="company-list">',entry+'<div class="company-list">',1)
 idx.write_text(t,encoding='utf-8')
# Update the existing report card rather than create a second article.
t=idx.read_text(encoding='utf-8')
t=t.replace('富时100、标普100与纳斯达克100：估值、分散与ETF选择','英美主要股票指数：富时、标普、纳指、道琼斯与罗素')
t=t.replace('实算估值、年末历史参照、9个成熟市场对照、12家公司财务代理及ETF持仓重叠；附10张小红书图文与数据脚本。','v1.1补充道琼斯与罗素1000/2000/3000；实算估值、亏损处理、年末历史、持仓重叠及费用，附14张小红书图文与数据脚本。')
t=t.replace('富时相对便宜但自身未处低位；纳指需要现金流兑现，标普100与纳指加权重叠55.05%。境内工具先防高溢价。','美国核心先比较全市场/大中盘；道指是价格加权蓝筹，小盘剔亏PE不代表整体便宜。富时与美国成长作结构分散。')
idx.write_text(t,encoding='utf-8')
readme=SITE/'finance/sectors/README.md';t=readme.read_text(encoding='utf-8')
if slug not in t:t=t.replace('# 行业和板块分析','# 行业和板块分析\n\n- [富时100、标普100与纳斯达克100：估值、分散与ETF选择]('+slug+') — 2026-11-21，附估值实算、年末快照限制、持仓重叠及小红书图集',1);readme.write_text(t,encoding='utf-8')
t=readme.read_text(encoding='utf-8').replace('富时100、标普100与纳斯达克100：估值、分散与ETF选择','英美主要股票指数：富时、标普、纳指、道琼斯与罗素').replace('附估值实算、年末快照限制、持仓重叠及小红书图集','v1.1新增道指及罗素1000/2000/3000，附亏损估值、持仓实算与14张小红书图集')
readme.write_text(t,encoding='utf-8')
# Check every internal link on both deliverable pages, resolve within site.
for file in [SITE/'finance/sectors'/slug,gallery/'index.html']:
 doc=BeautifulSoup(file.read_text(encoding='utf-8'),'html.parser')
 for node in doc.find_all(['a','img']):
  u=node.get('href') or node.get('src') or ''
  if not u or u.startswith(('http:','https:','#','mailto:','data:')):continue
  target=(file.parent/u.split('?',1)[0]).resolve()
  assert target.exists(),(file,u)
print('Verified 17 sections, 4 SVG charts, anchors and local links; copied report, gallery and data.')
