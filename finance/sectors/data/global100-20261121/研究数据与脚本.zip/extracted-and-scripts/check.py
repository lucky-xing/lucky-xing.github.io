from pathlib import Path
from bs4 import BeautifulSoup
import json,zipfile
p=Path('outputs/global100'); d=json.loads((p/'calculations.json').read_text(encoding='utf-8'))
assert abs(d['overlap']['minimumWeights']-55.05)<1e-8
assert abs(d['sixUS']['ocf']-d['sixUS']['capex']-d['sixUS']['fcf'])<1
for name,n in [('ftse-pe',10),('ndx-pe',10)]:assert d['annualStats'][name][-1]['N']==n
z=zipfile.ZipFile(p/'研究数据与脚本.zip');assert not any(x.endswith(('.html','.pdf','.xls')) for x in z.namelist())
s=BeautifulSoup((p/'xiaohongshu/index.html').read_text(encoding='utf-8'),'html.parser');assert len(s.select('article img'))==10
for old in ['医药','healthcare','7cfac17']:assert old not in str(s)
print('Arithmetic, samples, source archive scope and 10-page gallery passed.')
