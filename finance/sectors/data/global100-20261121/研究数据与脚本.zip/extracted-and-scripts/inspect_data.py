from pathlib import Path
from bs4 import BeautifulSoup
import json,re
P=Path('work/global100')
for k in ['oef','isf','qqqm','ndx-trailing']:
 s=BeautifulSoup((P/(k+'.html')).read_text(encoding='utf-8'),'html.parser')
 (P/(k+'.txt')).write_text(s.get_text(' ',strip=True),encoding='utf-8')
 print('\n',k)
 for a in s.find_all('a',href=True):
  if any(t in (a.get('href','')+' '+a.get_text(' ',strip=True)).lower() for t in ['csv','holdings','ajax','download','xlsx']):print(a.get_text(' ',strip=True)[:70],a['href'][:350])
 if k=='ndx-trailing':
  for script in s.find_all('script'):print(str(script)[:250])
a=json.loads((P/'ndx-forward.json').read_text());print('FWD KEYS',[(k,str(v)[:250]) for k,v in a.items()])
