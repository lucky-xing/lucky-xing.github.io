from pathlib import Path
import json,html,zipfile,shutil,math
from bs4 import BeautifulSoup
P=Path(__file__).parent
O=Path(r'D:\codex\2026-11-19\etf\outputs\global100')
SITE=Path(r'D:\codex\2026-10-19\i\work\report-site')
D=json.loads((O/'calculations.json').read_text(encoding='utf-8'))
slug='ftse-sp-nasdaq-100-2026-11.html'
url='https://lucky-xing.github.io/finance/sectors/'+slug
gallery='xiaohongshu/global100-20261121/'
def table(head,rows,caption=''):
 return '<div class="table-scroll" tabindex="0"><table><caption>'+caption+'</caption><thead><tr>'+''.join('<th>'+x+'</th>' for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(x)+'</td>' for x in r)+'</tr>' for r in rows)+'</tbody></table></div>'
def sec(i,title,body):return f'<section id="{i}"><h2>{title}</h2>{body}</section>'
def link(url,label):return f'<a href="{url}" target="_blank" rel="noopener">{label}</a>'
S={
'ftse':'https://siblisresearch.com/data/ftse-100-cape-pe-yield/',
'ndx':'https://siblisresearch.com/data/nasdaq-100-pe-ratio/',
'countries':'https://siblisresearch.com/data/pe-ratios-by-country/',
'oef':'https://www.ishares.com/us/products/239723/ishares-sp-100-etf',
'iqq':'https://www.ishares.com/us/products/351653/ishares-nasdaq-100-etf',
'isf':'https://www.ishares.com/uk/individual/en/products/251795/fund',
'qqqm':'https://www.invesco.com/us/en/financial-products/etfs/invesco-nasdaq-100-etf.html',
'qndx':'https://www.ssga.com/us/en/individual/etfs/state-street-spdr-portfolio-nasdaq-100-etf-qndx',
'qqq':'https://www.invesco.com/us/en/financial-products/etfs.html',
'equal':'https://www.cxfund.com.cn/products/qdii/519981/index.html',
'fees519981':'https://fundf10.eastmoney.com/jjfl_519981.html',
'ccbfund':'https://static.cninfo.com.cn/finalpage/2025-02-07/1222477607.PDF',
'efund':'https://static.cninfo.com.cn/finalpage/2026-08-11/1225467500.PDF',
'premium':'https://n.tinyright.com/',
'forward':'https://charts.allofthesewords.com/nasdaq100-fwdpe.html',
'nasdaq':'https://indexes.nasdaq.com/docs/FS_NDX.pdf',
'sp':'https://www.spglobal.com/spdji/en/indices/equity/sp-100/',
}
body=''
body+=sec('conclusions','一、先给判断：价值、成长、工具要分别选',
'''<div class="verdict"><strong>三者中，富时100更适合研究价值、股息和行业分散；纳斯达克100更适合承担成长风险；标普100是美国超大盘组合，并不自动成为更稳、更便宜的折中。</strong><br>当前证据支持“富时相对海外便宜、纳指需要增长兑现”，不支持“三者都处于历史低位”。境内纳指产品的高溢价，可能比每年0.2个百分点的费率差更值得回避。</div>'''+
table(['对象','实际估值与范围','当前判断','策略含义'],[
['富时100','2026-10末：正常化TTM PE 14.87；预期PE 11.97；CAPE 19.58','跨成熟市场样本相对便宜；自身近年不处于低位。绝对低估尚未证实','价值/股息/降低美股科技集中度优先研究；不因低PE直接重仓'],
['标普100','OEF 11/19管理人口径PE 28.44、PB 6.32；前十大证券50.58%','缺少同口径连续历史，历史位置不确定；当前不是深度价值型暴露','有明确超大盘偏好再选；通常无须与纳指各半重复买入'],
['纳斯达克100','10末正常化TTM PE 32.76、预期PE 21.24；IQQ 11/19管理人口径PE 31.11','盈利倍数偏高，历史年末样本也偏上；预期增长可消化部分估值，现金流安全边际薄','成长配置可分批，低溢价是前提；传统价值投资排序低于富时'],
],'当前数值不是同一张可直接排序的PE榜；下文分别锁定定义、日期与覆盖。')+
f'<p class="note">估值依据：{link(S["ftse"],"Siblis富时100")}、{link(S["ndx"],"Siblis纳指100")}；最新ETF快照：{link(S["oef"],"OEF")}、{link(S["iqq"],"IQQ")}。Siblis数据为第三方计算，非指数公司官方估值。</p>')
body+=sec('universe','二、同叫“100”，买到的现金流来源不同',table(['维度','富时100 / FTSE 100','标普100 / S&P 100','纳斯达克100 / Nasdaq-100'],[
['选样与权重','英国指数资格下的大型伦敦上市公司；自由流通市值加权','从标普500中选取美国大盘蓝筹；流通市值加权，并非简单机械取最大100只','纳斯达克上市的境内外大型非金融企业；修正市值加权'],
['业务画像','银行、能源、消费、医药与工业；大量全球业务','科技龙头＋金融、医药、消费等；更偏美国超大盘','科技、数字消费与通信等；排除金融企业，不等于纯科技指数'],
['主要收益来源','分红、回购、周期正常化和温和盈利增长','龙头利润增长、资本回报、估值变化','盈利扩张、创新商业化、增长预期与折现率变化'],
['主要失效风险','商品/信用周期反转、分红削减、英国相对折价长期不修复','龙头集中、科技与成长因子叠加、对其他宽基的费率溢价','高预期落空、AI资本开支回报不足、竞争和估值压缩'],
['汇率与地域','英镑报价≠全部收入在英国，也≠只有英镑经济风险','美元报价≠全部收入来自美国','美元报价，部分国际注册企业；仍强烈受美股风险偏好影响'],
]))
body+=sec('holdings','三、持仓实算：100只股票不等于充分分散',
table(['11/19基金代理','股票证券数','前十大证券权重','集中度等效持仓数*'],[[n,str(D['holdings'][k]['N']),f"{D['holdings'][k]['top10']:.2f}%",f"{D['holdings'][k]['effectiveN']:.1f}"] for k,n in [('isf','富时100：ISF'),('oef','标普100：OEF'),('iqq','纳指100：IQQ')]])+
'''<p>*等效持仓数＝1/Σ(股票权重归一化后)²，衡量权重集中，不衡量相关性。按证券计算，Alphabet两类股票未合并；合并公司后实际集中度会更高。ETF还持有少量现金/衍生品，不能把股票证券数当公司数。</p>
<div class="callout"><strong>OEF × IQQ：共同股票35只，加权重叠55.05%。</strong><br>公式：Σ min(w<sub>OEF,i</sub>, w<sub>IQQ,i</sub>)，以全部基金资产权重计算，未把现金归一化。共同股票覆盖OEF的63.45%、IQQ的74.94%；这三个数含义不同。指数代理之间存在复制误差，不代表未来重叠固定。</div>'''+
table(['前三大 / 11/19','第1','第2','第3'],[[n]+[f'{a} {b:.2f}%' for a,b in D['holdings'][k]['top'][:3]] for k,n in [('isf','ISF'),('oef','OEF'),('iqq','IQQ')]])+
'''<p>富时100金融25.51%、必选消费14.85%、工业13.75%、医疗12.88%、能源12.01%（ISF 11/18分类）。其分散优势主要来自行业与业务驱动不同，并非头部权重更低。纳指9/30官方ICB“科技”68.01%，不能与GICS“信息技术”直接相减。二者分类体系不同，比较时优先穿透到共同股票和盈利驱动。</p>'''+
f'<p class="note">原始持仓：{link("https://www.ishares.com/us/products/239723/ishares-s-p-100-etf/latest-holdings.csv","OEF CSV")}、{link("https://www.ishares.com/us/products/351653/ishares-nasdaq-100-etf/latest-holdings.csv","IQQ CSV")}；ISF由官网“Download”工作簿Holdings页提取。三者日期均为2026-11-19。分类来源：{link(S["isf"],"ISF")}、{link(S["nasdaq"],"Nasdaq官方事实表")}。</p>')
body+=sec('metrics','四、为什么选这些指标：用不同业务的价值驱动校验',
table(['业务','优先指标','与价值的经济联系','本期实际检验 / 失效条件'],[
['富时银行','PB或P/TBV＋可持续ROE/ROTE＋资本充足率','银行资本约束贷款与分红；PB必须由超过股权资本成本的盈利能力支撑','HSBC PB1.47、ROE14.22%；Barclays PB0.70、ROE10.45%。同属银行也不能只比PB；拨备和回购会改写回报'],
['能源/矿业','中周期经营利润或FCF＋净债务、维持性资本开支','商品价格高点的低PE会把峰值利润误当永续；正常化现金流更接近可分配价值','Shell现金流强，Rio分红/FCF代理约135%，周期与扩产仍需核查。未完成全周期正常化，不能把现时FCF永续化'],
['消费、医药等成熟业务','经常性PE＋FCF收益率、ROIC、分红覆盖','现金回收与资本回报决定利润可持续性；专利和品牌寿命限制终值','UL和AZN现金流收益率不同，需检查业务分拆、研发、专利和杠杆，不把调整利润一概当真实利润'],
['美国软件/平台与芯片','经常性盈利＋FCF＋增量ROIC/再投资回报；预期PE作交叉验证','成长价值来自未来新增现金流；AI建设期仅用利润可能忽略大量资本开支','六家主要共同成分FCF收益率代理1.73%，资本开支占CFO64.7%；芯片客户资本开支也是供应商收入，存在同周期依赖'],
['整个混合指数','同定义盈利倍数＋分业务校验＋权重集中度','任何单一指标都会被行业结构、亏损、会计和成分调整影响','本期没有全指数SOTP/DCF，不把银行FCF与科技FCF简单合并；PB不能作纳指主指标'],
])+
'''<div class="formula">稳定增长近似：P/B ≈ (ROE−g)/(k<sub>e</sub>−g)；P/E ≈ 可分配比例/(k<sub>e</sub>−g)。<br>企业价值取决于未来经营现金流及折现率；增长若消耗过多资本、回报低于资本成本，也可能降低价值。</div>
<p>银行的数量检查：仅取g＝0、假设k<sub>e</sub>＝10%–12%，HSBC ROE对应PB约1.19–1.42，当前1.47不算明显低；Barclays对应约0.87–1.05，高于当前0.70。它只是敏感性示例，TTM ROE与期末PB不是严格前瞻同口径，也没有计入资本约束、风险和增长，不能当目标价。银行存贷款变化会大幅影响CFO，不能套用“CFO−资本开支”判断银行便宜。</p>
<p><strong>不宣称某个指标与股价“相关性最高”。</strong>PE和股价共享分子，直接相关有机械性；本期是经济适用性和财务交叉校验，未完成带历史成分、当时预测、成本和样本外检验的1/3/5年前瞻回报回归。因此没有证据把任何一个指标称为统计最优。</p>''')

companyrows=[]
for r in D['companies']:
 t=r['ticker']
 if t in ['HSBC','BCS']:continue
 companyrows.append([link(f'https://stockanalysis.com/stocks/{t.lower()}/statistics/',t),f"{r['cap']/1e9:,.2f}",f"{r['ocf']/1e9:,.2f}",f"{r['capex']/1e9:,.2f}",f"{r['fcf']/1e9:,.2f}",f"{r['fcfYield']:.2f}%"])
body+=sec('cashflow','五、现金流实际有多贵：把负值保留下来',
table(['代表公司','市值/代理','CFO','资本开支','FCF代理','FCF/市值'],companyrows,'单位：十亿美元；FCF＝CFO−资本开支。此处均为美元口径公开聚合值；样本不等于完整指数。')+
'''<div class="callout">美国六股 AAPL/MSFT/NVDA/AMZN/GOOGL/META：市值代理合计19.96万亿美元；CFO 9,807.8亿美元，资本开支6,345.3亿美元，FCF 3,462.5亿美元，合计FCF收益率<strong>1.73%</strong>。负FCF未剔除；按总现金流/总市值计算，不平均个股比率。</div>
<p>美国六股市值统一用11/19管理人持仓的成分价格×Stock Analysis公布的近似总股数；Alphabet仅计一次，并以A类价格近似全公司股权，结果为代理值。它不是ETF实际权重加权估值：六股合计覆盖OEF约42.18%、IQQ约34.73%的净资产权重；未覆盖部分的估值不能由此推断。</p>
<p>AZN、SHEL、UL、RIO仅作富时业务举例，不合成富时指数估值。其市值为抓取页面显示值：AZN/RIO及银行页面报价在11/20美东10:57–10:59，SHEL/UL为11/19收盘；保留逐公司时点，不能视为同收盘可交易相对价值组合。Rio还存在双重上市结构，集团财务与具体上市证券口径需进一步桥接。</p>
<p>TTM财务取页面当时可得最新报表，未逐家重建经常性FCF；它不是纯FCFE/FCFF，利息、租赁、研发、营运资金、资本开支口径与并购影响未完全统一。利润与现金流分化是进一步核查信号，不是仅凭一季资本开支否定成长。也不能将全部AI支出都加回，假设成长无需投资。</p>
<p>结论：六股当前可见现金回报薄，需要未来增长与资本开支回报支撑；富时部分能源/消费样本现金回报更厚，但周期与负债风险也更大。这个结果支持风格判断，尚不支持精确测算全指数内在价值折价。</p>''')

histrows=[]
for key,label in [('ftse-pe','富时 正常化TTM PE'),('ftse-fpe','富时 预期PE'),('ftse-cape','富时 CAPE'),('ndx-pe','纳指 正常化TTM PE')]:
 z=D['annualStats'][key]
 histrows.append([label,f"{z[0]['current']:.2f}"]+[f"{r['percentile']:.1f}% / N={r['N']}" for r in z]+[f"{z[2]['median']:.2f}",f"{z[2]['p20']:.2f} / {z[2]['p80']:.2f}"])
histrows.append(['标普100 OEF管理人口径','28.44','缺口','缺口','缺口','缺口','缺口'])
def annualchart(arr,key,label,color,cap=None):
 vals=[r[key] for r in arr];mx=cap or max(vals)*1.12;lo=0;w=960;h=300;x0=55;y0=35;cw=850;ch=215
 pts=[];out=f'<svg viewBox="0 0 {w} {h}" role="img" aria-label="{label}年度快照"><title>{label}：2016–2025年末及2026年10月</title>'
 for tick in range(5):
  v=mx*tick/4;y=y0+ch*(1-v/mx);out+=f'<line x1="55" y1="{y}" x2="905" y2="{y}" stroke="#ffffff22"/><text x="5" y="{y+4}">{v:.0f}</text>'
 for i,r in enumerate(arr):
  x=x0+i*cw/(len(arr)-1);y=y0+ch*(1-min(r[key],mx)/mx);pts.append(f'{x:.1f},{y:.1f}')
 out+=f'<polyline points="{" ".join(pts)}" fill="none" stroke="{color}" stroke-width="3"/>'
 for i,(r,pt) in enumerate(zip(arr,pts)):
  x,y=map(float,pt.split(','));out+=f'<circle cx="{x}" cy="{y}" r="4" fill="{color}"/><text x="{x-22}" y="{y-12}">{r[key]:.2f}</text><text x="{x-18}" y="280">{r["date"][:4] if i<len(arr)-1 else "26/10"}</text>'
 return out+'</svg>'
body+=sec('history','六、时间维度：算出分位，也明确样本到底有多少',
'''<div class="warning"><strong>本节为“年末快照参照位置”，不是日频/月频历史分位。</strong>免费可核验的同源历史只有2016–2025十个年末。比较基准不含当前2026-10观察值；近3/5/10年分别只有3/5/10个历史点。无法据此精确判断交易日估值温度，2026年11月最新PE也不能直接套进10月这张表。</div>'''+
table(['序列 / 截至10末','当前','近3年年末参照','近5年年末参照','近10年年末参照','10年年末中位','10年20/80参考'],histrows)+
'''<p>计算＝历史观察值≤当前值的数量/N，倍数高分位代表更贵。窗口为2023/2021/2016-10-31至2026-10-31之间的可得历史年末；实际首末历史点分别为2023/2021/2016-12-31至2025-12-31。20/50/80参考值用线性分位数。源值只保留两位，富时2025年末14.87与当前同值，故近3年显示100%；这绝不等于“历史最高估值”。</p>'''+
f'<div class="chart"><h3>富时100：正常化TTM PE的年末快照</h3>{annualchart(D["ftseAnnual"],"pe","富时100 TTM PE","#81e5cd")}<p class="caption">2020年末169.52倍来自盈利分母坍缩，不能理解为当年股价最高。连线仅引导阅读，未插值补齐月度历史。</p></div>'+
f'<div class="chart"><h3>富时100：预期PE更平稳，但并非历史底部</h3>{annualchart(D["ftseAnnual"],"fpe","富时100 预期PE","#efbc83")}<p class="caption">10月11.97倍；10个年末中位12.34倍、5个年末中位11.24倍。时间窗口会改变“便宜”的答案。</p></div>'+
f'<div class="chart"><h3>纳指100：正常化TTM PE的年末快照</h3>{annualchart(D["ndxAnnual"],"pe","纳指100 TTM PE","#8fb8f8")}<p class="caption">10月32.76倍，高于10个年末中位28.36倍约15.5%；并非完整历史的80分位，更不是短期见顶信号。</p></div>'+
'''<p><strong>富时：</strong>TTM在10个年末中处于40%参照位置，但近5个年末是80%；CAPE在10个年末为70%。因此“比美国便宜”成立，“处在自身普遍低位”不成立。2020和2016的盈利异常还会抬高TTM中枢，不能只选最有利窗口。</p>
<p><strong>纳指：</strong>TTM年末参照偏上；前瞻盈利估值可能更温和，但预测兑现程度决定结果。<strong>标普100：</strong>没有找到可直接复算的同口径3/5/10年连续PE或FCF历史；不以标普500替代，也不把价格回撤当估值分位，历史判断保留不确定。</p>
<details><summary>核查到的另一套纳指预期PE：为什么没有拼进主表</summary><p>History of Market公开周频终端序列截至2026-08-05为22.37倍；每月取最后一个可得值，排除当前所在月未完成点，近3/5/10年月频参照为8.3%/21.7%/47.5%，N=36/60/120。它描述的是8月5日，不是11月。8/5以后另用持仓与FY1/FY2预期混合的日频估算，11/19为17.86倍，覆盖99.59%。终端供应商未披露，两种算法只在一个日期接近，不能据此认定一致。因此不将其合并，也不发布“11月当前处于10年低分位”。原始JSON留档用于审阅，主结论不依赖它。</p>'''+link(S['forward'],'公开图表及方法')+'</details>')

peers=[['英国 / 富时100','14.87','11.97']]+[[c,f'{p:.2f}',f'{f:.2f}'] for c,p,f in D['matureSample']]+[['纳指100（美国风格指数，单列）','32.76','21.24']]
body+=sec('international','七、横向对标：富时便宜多少，为什么不能全部当折价收益',
table(['2026-10末 / 同一来源','正常化TTM PE','预期PE'],peers,'Siblis公开数据；US表示U.S. Large Cap，绝非标普100。国家指数与风格指数并非等风险资产。')+
'''<p>选择美国、加拿大、澳大利亚、日本、荷兰、德国、法国、西班牙、意大利9个其他发达市场指数作参照，英国不进入分母。TTM PE中位17.64倍；富时14.87倍低15.7%，在这9个样本的11.1%位置（只有意大利更低）。预期PE中位14.66倍，富时低18.3%、样本位置22.2%。纳指TTM高于全部9个样本，样本位置100%，这只是小样本跨指数位置，绝非“全球100分位”。</p>
<p>同源10月数据下，纳指TTM是富时的2.20倍、预期PE是1.77倍；预期/TTM差额隐含的盈利增幅分别约54.2%和24.2%。这个比值是相同价格下的分母关系，混有正常化与预测口径，不能直接当未来一年有把握实现的EPS增长率。更快增长、较高资本回报和轻资产历史可以解释部分溢价；银行、能源的周期风险和较慢增长可以解释部分英国折价。</p>
<p>没有完成行业中性、杠杆、税、研发/租赁会计和增长调整，故不将上述15.7%折价视为应当上涨15.7%，更不把英美倍数差直接当套利。未获得相对估值比率的完整同期历史，本期也不报“英美折价处于历史第几分位”。</p>'''+
f'<p class="note">数据：{link(S["countries"],"Siblis各国表")}、{link(S["ndx"],"纳指及美国大盘表")}。跨国比较的选择、计算和判断为本研究。</p>')

body+=sec('reconcile','八、同一个指数，为什么会看到不同的PE',
table(['对象 / 来源','日期','PE','定义与用途'],[
['富时 / Siblis','10/31','14.87（TTM）；11.97（预期）','总市值/正常化TTM净利与未来12月一致预期；与自身年末历史、同源各国比较'],
['富时 / ISF','11/18','17.64','管理人页面P/E；其事实表Glossary指当年预测盈利口径，不强行归类为TTM；不用它与OEF做同口径折价计算'],
['标普100 / OEF','11/19','28.44','管理人估值；事实表说明成分TTM、剔除负盈利与非常项目、超过60倍按60计；不等于含亏损的总市值/总净利润'],
['纳指100 / IQQ','11/19','31.11','同一家美国管理人展示口径；用于与OEF的近期粗对照，不混入Siblis历史'],
['纳指100 / QQQM','10/30','27.02；预期24.44','不同管理人算法与时间，不能将27.02→31.11理解成20天估值上升15%'],
])+
'''<p>OEF相对IQQ的管理人PE低约8.6%，说明“标普100天然比纳指便宜很多”也不稳妥。它们有不同盈利覆盖和特殊项目处理；这里只作管理人口径交叉验证，不把倒数直接当全指数真实盈利收益率。</p>
<p>需要最新决策时，优先获取同一估值日、同定义、同亏损处理的组合数据。本报告保留10月底共同估值截面、11/19ETF持仓快照和逐公司财务代理三个层次，不把各自“最新”拼成一个没有日期的价格判断。</p>''')

body+=sec('funds','九、买什么工具：按渠道和用途比较',
table(['暴露 / 产品','代码与渠道','已核费率 / 年','判断'],[
['富时100 / iShares Core','ISF，伦敦上市、爱尔兰UCITS','TER 0.07%','可用境外渠道时的长期低成本候选；分红型，注意英镑报价、交易费用及账户可买性'],
['富时100 / 建信','539003人民币A；008706人民币C，境内场外QDII','管理0.80%＋托管0.20%；C另0.40%销售服务','境内可达性强但持有成本明显高于ISF；不是场内ETF。申购额度以当天管理人/渠道为准'],
['标普100市值权重 / iShares','OEF，美股ETF','0.20%','精确表达OEX市值加权暴露；买的是超大盘集中度，未证明优于更广泛美国宽基'],
['标普100等权增强 / 长信','519981人民币，境内场外QDII','公开费率页管理1.10%＋托管0.20%','不是OEF替代品：等权、至少80%复制部分、主动部分≤15%，还有现金与增强风险。费用须交易前核最新概要'],
['纳指100 / State Street','QNDX，美股ETF','0.10%','海外低费候选；2026年6月成立，仍需比较实时点差、成交和真实跟踪，不只看名义费率'],
['纳指100 / Invesco','QQQM，美股ETF','0.15%','长期买持的成熟候选；比QQQ便宜，但已不是最低名义费率'],
['纳指100 / iShares','IQQ，美股ETF','总0.12%，豁免后0.10%至2027-07-31','低费替代候选；豁免期后费率和较短业绩历史需持续看'],
['纳指100 / Invesco','QQQ，美股ETF','0.18%','偏重流动性/期权交易的候选；无这类需求，长期买持优先比较更低费产品'],
['纳指100 / 易方达','159696，境内ETF','管理0.50%＋托管0.10%','相对低费的境内候选，但当前高参考溢价会压倒费率优势；等待合理交易价'],
['纳指100 / 华安等','159632、513100等境内ETF','159632公开页0.60%＋0.20%；其他逐只核','选实时可比溢价、点差和跟踪，不按规模或过去涨幅直接排名'],
])+
'''<p>境外费率多为TER/净费率，境内上述是管理＋托管＋服务费项目，不是完整税后总持有成本；还需加交易点差、佣金、换汇、税和其他运作费用。QDII净值已扣费，不重复减。管理人注册地、投资者税务身份和账户不同，税负可能不同，本期没有给出统一税后排名。</p>
<p>A/C简单费用检查：若A实际申购费打折至0.12%、C服务费0.40%/年，忽略赎回费差异，持有约0.3年后A的累计显性费用更低；若A费1.20%，则约3年。实际还要核赎回费、渠道折扣和份额规则，不能笼统说“C短持一定更划算”。</p>'''+
f'<p class="note">来源：{link(S["qndx"],"QNDX")}、{link(S["qqqm"],"QQQM")}、{link(S["qqq"],"Invesco当前产品表")}、{link(S["iqq"],"IQQ")}、{link(S["ccbfund"],"建信基金合同")}、{link(S["equal"],"长信产品")}、{link(S["fees519981"],"长信公开费率页")}、{link(S["efund"],"易方达产品概要")}。长期合同费率是否另有更新，交易前再核。</p>')

prem=[(0,.0),(0.10,.0),(0.15,.0),(.20,.0)]
body+=sec('premium','十、境内纳指高溢价：可以把好标的买成坏投资',
'''<p>11/20公开看板记录：159632收盘2.282元、参考IOPV 2.0142（估值日11/19），算术差13.30%；159696收盘1.935元、参考1.6513（11/19），算术差17.18%。它们是<strong>非同步参考溢价</strong>，不等于15:00完全公允的实时溢价，更不等于无风险套利空间。不同看板因净值日与时差处理不同，显示会不一致；本报告不据此给同一时点精确产品排名。</p>'''+
table(['进入溢价 → 退出溢价','底层本币总回报0%','底层本币总回报+10%'],[[f'{p:.0%} → 0%',f'{(1/(1+p)-1)*100:.2f}%',f'{(1.10/(1+p)-1)*100:.2f}%'] for p,_ in prem])+
'''<div class="formula">人民币交易回报近似＝(1＋底层总回报)×(1＋外币兑人民币变动)×(1＋退出溢价)/(1＋进入溢价)−1−未内含成本。</div>
<p>上表假设汇率不变、不计尚未内含的费用。15%溢价归零，标的不涨也要损失13.04%；底层涨10%，仍亏4.35%。若只为省每年0.2个百分点费用去买入高出10个百分点的溢价，忽略复利时约需50年费用差才能抵消；短期退出溢价无法保证。</p>
<p>执行偏好：确认时差后的溢价≤1%才进入常规候选，1%–3%等待/小额比较，&gt;3%不作为长期新增首选；这些是本研究的成本纪律，非监管阈值。申购暂停、额度紧张可能令溢价延续，不做无保证套利。场外额度不可得时，等待也比被迫高价买入更合理。</p>'''+
f'<p class="note">快照及字段解释：{link(S["premium"],"naKanban公开看板")}；该二级聚合快照不替代基金公司净值与交易所行情。数据已留档描述，未将其当官方同步报价。</p>')

body+=sec('strategy','十一、不同策略下，分别怎么选',
table(['策略','本期优先研究','为什么 / 什么情况下不适合'],[
['传统价值 / 现金回报','富时100，境外ISF；境内539003按额度和成本','相对成熟市场折价、较厚股息及成熟业务更符合目标；但自身历史不算极低，分红和周期必须持续'],
['质量成长 / 长期积累','纳指100：QQQM或低费QNDX；IQQ看豁免后费率','未来盈利增长空间更大，当前现金流价格较紧；能承受明显回撤、无需短期资金才讨论配置'],
['美国超大盘蓝筹','OEF','有明确超大盘目的可选；若只是泛美股核心，先比较更广泛、成本更低的宽基，不能由名称“100”判优'],
['均值回归 / 因子轮动','富时相对美国成长的观察组合','同源估值差存在，但没有相对比率完整历史；不设伪精确价差目标，不加杠杆'],
['等权再平衡','519981单独评估，不套OEF结论','降低巨头占比、增加其余蓝筹暴露；增强和费用可能改变结果，尚未核全持仓估值/实际超额，暂不评最优'],
['趋势 / 动量','纳指可作交易对象，先等趋势恢复','不因PE低或跌幅大就接下跌；本期未获取完整统一日线/宽度和成交验证，不发布当前买入信号'],
['股息现金收入','富时更贴近目标，仍需核实际分配','ISF历史分配率11/19约3.12%，不是保本利息或未来承诺；境内基金未必定期现金分红'],
['组合分散','美国成长＋适量富时，比标普100＋纳指机械各半更有结构差异','只是股票内部风格分散，两地仍受全球风险偏好冲击；不能替代现金、债券或整体资产配置'],
]))

scenarios=[]
for name,m0,vals in [('富时',11.97,[(-.10,10),(.05,12),(.15,13)]),('纳指',21.24,[(-.10,18),(.15,21),(.30,24)])]:
 for lab,(g,m1) in zip(['压力','中性假设','乐观'],vals):scenarios.append([name,lab,f'{g:+.0%}',f'{m1:.0f}倍',f'{((1+g)*m1/m0-1)*100:+.1f}%'])
body+=sec('scenarios','十二、把估值变成可核查条件，而不是凭空目标价',
table(['对象','非概率情景','预期盈利基准修正','退出预期PE','本币价格变化代理*'],scenarios)+
'''<p>*起点使用10月同源预期PE：富时11.97、纳指21.24；价格变化＝(1＋盈利修正)×退出PE/起点PE−1。这是“预期盈利基准被修正＋估值变化”的静态敏感性，不是未来一年EPS增长预测，也不是12个月目标回报。尚未计股息、汇率、费用及ETF溢价，不能用不同日期的ETF价格机械换算目标价。中性只是参数标签，没有估计发生概率。</p>
<p><strong>富时增加条件：</strong>同源预期PE降向11倍附近（约为历史5个年末较低区域）且银行资本、股息覆盖、能源中周期盈利没有同步恶化；若盈利预期下降，价格必须相应重估。当前11.97并未触发“明显历史便宜”。<strong>纳指增加条件：</strong>在经常性利润与资本开支回报改善下，等待同源预期PE向18–20倍敏感区靠拢或盈利上修令估值自然降低；这个区间是压力测试参数，不冒充已验证历史买点。</p>
<p><strong>减少或暂停条件：</strong>纳指盈利预期上修停滞而资本开支持续吞噬现金，或组合共同巨头超出风险预算；富时出现持续分红削减、信贷损失/商品中周期下修；任何境内产品同步校正后溢价明显扩大。<strong>标普100：</strong>需补齐同口径估值历史/完整现金流再定估值买点，当前不设伪精确目标价。</p>
<p>回撤承受能力检查：2022年ISF净值总回报约+4.62%（GBP）、OEF约−21.01%（USD）；QQQ市价总回报约−32.58%（USD）。这不是同币种收益排名，也不是区间最大回撤；只是说明风格可能有很不同的年度损失路径。人民币投资者还需汇率，不能保证富时每轮下跌都能对冲纳指。</p>'''+
f'<p class="note">年度数据：ISF与OEF管理人事实表；QQQ见{link("https://www.invesco.com/qqq-etf/en/innovation/understanding-qqqs-performance-through-market-cycles.html","Invesco市场周期说明")}（此旧文费率已过时，当前费率用产品表）。</p>')

body+=sec('evidence','十三、证据、日期与尚未完成的部分',
'''<p>研究整理于2026-11-21；网页/原始资料采集于11/20。共同跨国估值截面截至10/31（非交易日，沿用月底发布口径），ETF完整持仓截至11/19；最新估值字段各自注明日期。11/20全天行情没有纳入统一收盘截面，本报告不称“11/21实时估值”。财务为采集时可得TTM聚合数据。</p>
<ul><li>历史：富时与纳指公开年末快照，非连续日/月频。标普100缺同口径历史。没有用指数价格图反推PE。</li><li>当前：ETF管理人PE可能剔亏、封顶或用预测盈利，不能当成总市值/总利润。全指数经常性盈利、FCF、亏损覆盖和SOTP尚未重建。</li><li>国际：9个其他成熟市场指数的小样本；不是行业匹配后的公司估值分位，没有估计完整全球市场分布。</li><li>财务：公司样本为业务交叉检查；FCF代理含利息和会计差异，未将银行纳入FCF篮子。没有回填不同时点的预测历史。</li><li>持仓：统一11/19股票权重计算，按证券而非经济风险因子；没有据此估计未来收益相关性。</li><li>基金：未验证所有境内产品当前申购额度、全费用与实际跟踪结果；给出条件候选，不给全市场“最佳ETF”认证。</li></ul>
<div class="actions"><a href="data/global100-20261121/calculations.json">计算结果JSON ↓</a> · <a href="data/global100-20261121/研究数据与脚本.zip">原始证据与计算脚本ZIP ↓</a> · <a href="xiaohongshu/global100-20261121/">小红书封面与图集预览 ↗</a></div>
<p>复算主文件为analyze.py；原始HTML/PDF/CSV/Excel保存在本地研究目录。网页下载包提供数值提取、计算结果、采集/计算脚本与原始链接，不镜像发布第三方整页正文。第三方资料权利归原作者。研究判断是条件性分析，不构成个性化投资建议。</p>'''+
'<details><summary>主要原始来源与对应用途</summary><ol>'+''.join('<li>'+link(u,k)+'</li>' for k,u in [('FTSE：同源当前与年末历史',S['ftse']),('Nasdaq：当前、增长和年末历史',S['ndx']),('成熟市场横截面',S['countries']),('OEF：最新管理人估值与持仓入口',S['oef']),('ISF：最新特征与Excel下载入口',S['isf']),('IQQ：最新管理人估值与持仓入口',S['iqq']),('Nasdaq官方指数画像',S['nasdaq']),('S&P官方指数规则与画像',S['sp']),('QQQM当前费率与特征',S['qqqm']),('QNDX费率',S['qndx']),('长信：等权增强范围',S['equal']),('建信费率合同',S['ccbfund']),('易方达费率概要',S['efund']),('非同步参考溢价',S['premium'])])+'</ol></details>')

old=(SITE/'finance/sectors/healthcare-etf-2026-11.html').read_text(encoding='utf-8')
css=old.split('<style>',1)[1].split('</style>',1)[0]
css+='\n.research{padding-top:55px}.research caption{font-size:14px}.research .actions{line-height:2.5}.research .data-status{color:#efbc83} @media(max-width:650px){.research{padding-top:40px}}'
page=f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>富时100、标普100与纳斯达克100：估值、分散与ETF选择 · Lighting Future</title><meta name="description" content="三类100指数的实际估值、年末历史参照、成熟市场比较、现金流实算与ETF成本。"><link rel="stylesheet" href="../../style.css"><style>{css}</style></head><body class="theme-finance insight-page"><a class="skip" href="#report">跳到正文</a><header class="wrap"><a class="brand" href="../../index.html"><span class="mark">LF</span>Lighting Future</a><nav><a href="../../finance.html">投资理财</a><a href="index.html">行业和板块分析</a></nav></header><main class="research" id="report"><span class="draft-tag">v1.0 / 实算研究与审阅版</span><br><span class="eyebrow">GLOBAL 100 · VALUATION · ETF</span><h1>富时100、标普100<br>与纳斯达克100</h1><p>全球价值、美国蓝筹与成长，如何估值，如何选工具？</p><p class="meta">2026-11-21整理｜共同估值截面2026-10末｜持仓2026-11-19｜公司财务TTM代理｜历史仅有年末快照，非连续分位</p><nav class="toc">'''+''.join(f'<a href="#{i}">{t}</a>' for i,t in [('conclusions','结论'),('holdings','持仓重叠'),('metrics','指标选择'),('cashflow','现金流实算'),('history','历史参照'),('international','海外对标'),('reconcile','口径差异'),('funds','基金比较'),('premium','溢价成本'),('strategy','策略'),('scenarios','情景'),('evidence','数据与来源')])+f'<a href="{gallery}">小红书图集 ↗</a></nav>'+body+'</main><footer class="wrap"><a href="index.html">返回行业和板块分析</a><span>Lighting Future · 持续记录</span></footer></body></html>'
(O/slug).write_text(page,encoding='utf-8')
# Evidence archive: all public snapshots and calculation code, no credentials.
manifest={'researchDate':'2026-11-21','retrievedDate':'2026-11-20','sources':S,'notes':'HTML/CSV/PDF/Excel are public research evidence; calculations use annual snapshots only. Market dates differ and are disclosed per section.'}
(O/'sources.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
with zipfile.ZipFile(O/'研究数据与脚本.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in P.iterdir():
  if f.is_file() and (f.suffix=='.py' or (f.suffix=='.json' and f.name!='ndx-forward.json')):z.write(f,'extracted-and-scripts/'+f.name)
 for f in [O/'calculations.json',O/'sources.json']:z.write(f,f.name)
print('Report and evidence generated:',O)

