from pathlib import Path
from bs4 import BeautifulSoup
import json,csv,io,re
P=Path('work/global100')
for k in ['oef','iqq']:
 t=(P/(k+'-holdings.csv')).read_text(encoding='utf-8-sig');rows=list(csv.DictReader(io.StringIO(t[t.index('Ticker,'):])));eq=[r for r in rows if r.get('Asset Class')=='Equity'];eq.sort(key=lambda r:float(r['Weight (%)']),reverse=True)
 print(k,'equities',len(eq),'sum',sum(float(r['Weight (%)']) for r in eq),'top10',sum(float(r['Weight (%)']) for r in eq[:10]),[(r['Ticker'],r['Weight (%)']) for r in eq[:10]])
 (P/(k+'-equities.json')).write_text(json.dumps(eq,indent=2),encoding='utf-8')
 if k=='oef':o={r['Ticker']:float(r['Weight (%)']) for r in eq}
 else:q={r['Ticker']:float(r['Weight (%)']) for r in eq}
print('overlap',len(set(o)&set(q)),sum(min(o.get(t,0),q.get(t,0)) for t in set(o)|set(q)), 'OEFcovered',sum(o[t] for t in set(o)&set(q)),'NDXcovered',sum(q[t] for t in set(o)&set(q)))
for k in ['stats-azn','stats-shel','stats-ul','stats-rio']:
 s=BeautifulSoup((P/(k+'.html')).read_text(encoding='utf-8'),'html.parser').get_text(' ',strip=True)
 i=s.find('Cash Flow');print(k,s[i:i+1200])
p=P/'isf-download.xls';print('isfheader',p.read_bytes()[:100])
s=BeautifulSoup((P/'siblis-countries.html').read_text(encoding='utf-8'),'html.parser');print('\nCOUNTRIES\n',s.find('table').get_text(' | ',strip=True)[:6000])
