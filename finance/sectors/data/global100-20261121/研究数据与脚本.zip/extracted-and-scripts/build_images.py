from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,html,zipfile,re
ROOT=Path(r'D:\codex\2026-11-19\etf')
OUT=ROOT/'outputs/global100/xiaohongshu'
OUT.mkdir(parents=True,exist_ok=True)
# Reuse the accepted deterministic visual system; no old report content is run.
src=(ROOT/'work/build_xhs_images.py').read_text(encoding='utf-8').split('files=[]',1)[0]
src=src[src.index('W,H='):]
src=src.replace("{n:02d} / 10","{n:02d} / 14")
exec(src)
def footer(note='个人研究 · 非个性化投资建议'):
 d.line((72,1301,1008,1301),fill=LINE,width=2)
 text(72,1320,'整理 2026.11.21 / 估值10月末、持仓11.19',24,MUTED)
 text(72,1360,note,23,MUTED,width=936)
files=[]
start(1,'英美宽基 × 估值实算 / v1.1','指数这么多\n该怎么选？')
text(72,460,'富时 / 标普 / 纳指 / 道琼斯 / 罗素',35,MINT,True)
for y,a,b in [(590,'价值与股息','富时相对便宜，自身并非低位'),(760,'美国核心配置','先比较罗素3000 / 1000等宽基'),(930,'风格倾斜','纳指看成长，小盘别只看剔亏PE')]:
 box(72,y,936,144);text(100,y+18,a,29,MUTED);text(100,y+65,b,38,INK,True)
text(72,1160,'先比较现金流，再决定买什么。',36,MINT,True)
footer('包含实际估值、年末参照和基金成本');files.append(save(1,'封面'))

y=start(2,'当前估值 / 先把日期对齐','便宜和成长\n是两回事')
y=metrics(y,['10月末 / 同源','TTM PE','预期PE'],[('富时100','14.87','11.97'),('纳斯达克100','32.76','21.24')],[430,253,253])
y=callout(y+20,'富时：相对成熟市场较低','但近年自身估值不在底部；\n能源、银行周期不能忽略。',h=205)
y=callout(y,'纳指：仍有成长定价','更高增长能消化估值，\n前提是预期变成利润与现金。',GOLD,h=205)
text(72,y,'来源：Siblis正常化TTM / 未来12月预期\n标普100另用OEF口径，不硬放同一榜。',28,MUTED,spacing=14)
footer('第三方指数估值，非指数公司官方数据');files.append(save(2,'当前估值'))

y=start(3,'时间维度 / 不伪装精度','富时：海外便宜\n自身未必便宜')
y=metrics(y,['指标 / 10月末','当前','10年末参照'],[('TTM PE','14.87','40%'),('预期PE','11.97','50%'),('CAPE','19.58','70%')],[430,210,296])
y=callout(y+14,'只有10个历史年末点','2016—2025，N=10；\n不是日频或月频历史分位。',GOLD,215)
text(72,y+10,'近5个年末：\n富时TTM与预期PE都在80%位置。',36,INK,spacing=17)
text(72,y+160,'疫情盈利坍缩会扭曲TTM中枢，\n不能只挑最便宜的那个窗口。',31,MUTED,spacing=15)
footer('分位＝历史点≤当前的比例；当前不进分母');files.append(save(3,'历史位置'))

y=start(4,'海外对标 / 同源10月截面','富时折价多少？\n先看参照是谁')
text(72,y,'−15.7%',112,MINT,True);y+=170
text(72,y,'富时TTM PE 14.87\n其他9个发达市场样本中位17.64',37,INK,spacing=18);y+=155
y=callout(y,'样本位置 11.1%','9个样本中只有意大利更低；\n这不是全球市场分位。',h=205)
y=callout(y,'折价 ≠ 应涨幅','行业、增长、资本回报和风险不同；\n未完成行业中性和会计调整。',GOLD,215)
text(72,y,'样本：美、加、澳、日、荷、德、法、西、意\n美国样本为U.S. Large Cap，不是标普100。',26,MUTED,spacing=13)
footer('来源Siblis；英国未进入9个参照样本分母');files.append(save(4,'海外参照'))

y=start(5,'组合分散 / 11月19日持仓实算','标普100＋纳指\n有多少重复？')
text(72,y,'55.05%',116,MINT,True);y+=175
text(72,y,'加权重叠＝Σ min(两只基金股票权重)',29,MUTED);y+=90
y=metrics(y,['共同股票覆盖','OEF','IQQ'],[('35只共同股票','63.45%','74.94%'),('前十大证券','50.58%','46.17%')],[430,253,253])
y=callout(y+25,'各买一半仍偏美国成长','富时的行业驱动差异更大，\n但富时前十大也占48.37%。',GOLD,h=215)
text(72,y,'基金代理：OEF标普100 / IQQ纳指100\n按证券计算，含Alphabet两类股票。',28,MUTED,spacing=16)
footer('原始股票权重，不对现金归一化；非相关系数');files.append(save(5,'持仓重叠'))

y=start(6,'估值交叉检查 / 不只看PE','利润增长之外\n现金留下多少？')
text(72,y,'1.73%',120,GOLD,True);y+=180
text(72,y,'六家美国共同成分的FCF收益率代理',32,INK,True);y+=90
y=metrics(y,['美元 / 亿','合计','定义'],[('经营现金流','9,807.8','CFO'),('资本开支','6,345.3','减项'),('FCF代理','3,462.5','CFO−开支')],[430,270,236])
text(72,y+15,'AAPL / MSFT / NVDA / AMZN / GOOGL / META\n负FCF保留，合计现金流÷合计市值代理。',27,MUTED,spacing=15)
text(72,y+130,'不能把所有AI投资加回，\n假设成长不需要资本。',39,INK,True,spacing=17)
footer('六股≠指数；近似股数×11.19价格，非纯FCFE');files.append(save(6,'现金流'))

y=start(7,'选基金前 / 名字可能误导','长信标普100\n不等于OEF')
y=callout(y,'OEF：市值加权标普100','大公司权重大；\n费率0.20%/年。',h=210)
y=callout(y,'519981：等权＋增强','等权复制与主动部分混合；\n公开页管理＋托管约1.30%/年。',GOLD,h=230)
y=callout(y,'风格、成本都不同','看好OEF，不代表可以直接\n用519981代替。',h=210)
text(72,y,'富时境内539003也不是场内ETF。\n申购额度与最新费用需当天再核。',30,MUTED,spacing=15)
footer('长信费用取公开费率页；交易前核最新概要');files.append(save(7,'名称差异'))

y=start(8,'交易成本 / 买贵会吞掉收益','15%溢价归零\n要付什么代价？')
y=metrics(y,['底层回报','退出溢价','交易回报*'],[('0%','0%','−13.04%'),('+10%','0%','−4.35%')],[330,290,316])
y=callout(y+20,'11/20看板参考差额','159632约13.30%；159696约17.18%。\n参考净值日为11/19，非同步溢价！',GOLD,h=230)
text(72,y,'时差后的公允净值需重新核算，\n看板数字不等于无风险套利空间。',32,INK,spacing=18)
text(72,y+140,'*进入溢价15%，汇率不变，\n未计尚未内含的费用；只是情景计算。',28,MUTED,spacing=15)
footer('快照来源naKanban，非官方同步成交报价');files.append(save(8,'溢价成本'))

y=start(9,'工具选择 / 按目的比较','哪个ETF更好？\n先确定目的')
for a,b,c in [('价值与股息','ISF / 539003','前者境外低费，后者境内场外'),('纳指长期买持','QQQM / QNDX','费率0.15% / 0.10%，还看点差'),('美国超大盘','OEF','费率0.20%，集中暴露要有理由'),('境内纳指','159696等','相对低费不等于高溢价也能买')]:
 box(72,y,936,173);text(100,y+17,a,30,MUTED);text(100,y+60,b,40,MINT,True);text(100,y+120,c,29,INK);y+=194
footer('候选非全市场排名；费用口径与渠道不同');files.append(save(9,'基金选择'))

# New integrated four-page extension.
y=start(10,'道琼斯 / 价格加权蓝筹','道指不是\n市值最大的30股')
text(72,y,'17.78',112,MINT,True);y+=170
text(72,y,'DIA / 11.19 / FY1预期PE',32,MUTED);y+=85
y=callout(y,'股价高，权重可能更大','高盛约10.25%，苹果约4.22%；\n不是因为高盛市值超过苹果。',h=210)
y=callout(y,'可研究蓝筹风格','预期倍数温和，未证实内在低估；\n前十大占股票仓位54.11%。',GOLD,h=215)
text(72,y,'FY1是预测当年盈利，不是TTM或NTM。\n道指同口径历史分位仍有缺口。',28,MUTED,spacing=16)
footer('来源DIA官方；权重11.19，集中度剔现金');files.append(save(10,'道琼斯'))

y=start(11,'罗素体系 / 规模不是配比','3000＝1000\n＋2000')
y=callout(y,'罗素3000：美国全市场','约3,000家公司，约98%可投资市值；\n不等于大中小盘各占三分之一。',h=210)
y=callout(y,'1000大中盘 / 2000小盘','按市值加权，不能按股票数量\n用1:2资金比例复制3000。',h=210)
y=callout(y,'真实持仓穿透','IWV股票仓位约96.10%属于IWB证券，\n小盘部分约3.90%，仍由大盘主导。',GOLD,h=215)
text(72,y,'2026起半年重构；本轮12月11日收盘后生效。\n实际ETF抽样持仓不必正好等于指数名称。',27,MUTED,spacing=16)
footer('LSEG规则；IWV/IWB/IWM 11.19股票市值重建');files.append(save(11,'罗素体系'))

y=start(12,'罗素2000 / 亏损不能消失','17倍还是35倍？\n先问算了谁')
y=metrics(y,['估值定义','日期','PE'],[('IWM管理人剔亏等','11.19','17.74'),('整体正常化TTM','10月末','35.77'),('整体预期NTM','10月末','23.14')],[510,210,216])
y=callout(y+15,'算法与日期都不同','亏损抵减组合盈利，整体PE会更高；\n不能将差额全归因为亏损。',GOLD,h=215)
text(72,y,'整体盈利收益率约2.80%。\n不支持仅凭17.74倍认定小盘整体便宜。',34,INK,spacing=17)
text(72,y+150,'10年仅9个有效年末PE点，另有1个亏损年；\n33.3%是正盈利年份参照，不是连续分位。',27,MUTED,spacing=16)
footer('IWM官方、Siblis；亏损比例未完成统一核算');files.append(save(12,'小盘估值'))

y=start(13,'扩展ETF / 核心与风格分开','先选核心\n再加倾斜')
for aa,bb,cc in [('美国大中盘核心','IWB / VONE','年费0.15% / 0.06%'),('美国全市场核心','IWV / VTHR','年费0.20% / 0.06%'),('美国小盘倾斜','IWM / VTWO','年费0.19% / 0.06%'),('特定蓝筹风格','DIA / 境内513400','境外0.16%；境内管理＋托管0.65%')]:
 box(72,y,936,172);text(100,y+15,aa,29,MUTED);text(100,y+61,bb,40,MINT,True);text(100,y+120,cc,28,INK);y+=192
footer('还需比较点差、税、换汇及准入；非总成本排名');files.append(save(13,'扩展ETF'))

y=start(14,'阅读边界 / 原始证据可复算','三个问题\n分开回答')
for a,b in [('现在贵不贵？','写清估值日期、盈利与现金流口径。'),('历史低不低？','只有年末样本，不冒充连续分位。'),('工具值不值得买？','指数估值与ETF溢价、费率分开。')]:
 y=callout(y,a,b,h=180)
text(72,y+8,'道指、标普100、罗素1000/3000历史有缺口。\n罗素2000只有年末点，亏损年份不可忽略。\n绝对价值：未完成全指数DCF或SOTP。',29,MUTED,spacing=20)
box(72,1130,936,115,fill='#1c3440');text(100,1153,'完整研究 / 原始数据 / 计算脚本',31,MINT,True);text(100,1200,'见配套网页入口，保留来源和限制',27,INK)
footer('网站配套图文，未自动发布至小红书');files.append(save(14,'口径与来源'))

post='''英美宽基这么多，该怎么选？

这次把道琼斯、罗素1000/2000/3000补进了富时、标普和纳指研究。

① 美国核心：先比较全市场与大中盘。
罗素3000≈1000大中盘＋2000小盘，但不能按股票数量配成1:2。11/19实际IWV股票仓位约96.10%属于IWB证券，小盘部分约3.90%，仍由大盘主导。

② 道琼斯：30股价格加权蓝筹。
DIA 11/19 FY1预期PE17.78；高盛约10.25%、苹果约4.22%，不是按公司市值分权重。预期倍数温和，但未证实内在低估。

③ 罗素2000：17倍不等于整体便宜。
IWM管理人11/19 PE17.74，有剔亏、封顶等处理；同源10月末整体正常化TTM PE35.77、预期23.14。日期和算法都不同，亏损抵减整体盈利，不能硬比。

④ 富时：相对便宜，自身未必低位。
10月末正常化TTM PE14.87；较9个其他发达市场样本中位低15.7%，但自身近5个年末参照80%。

⑤ 纳指：作为成长倾斜。
同源10月TTM PE32.76，仍需盈利和现金流兑现。标普100与纳指代理11/19净资产权重重叠55.05%，各买一半不等于充分分散。

工具候选：大中盘IWB/VONE；全市场IWV/VTHR；小盘IWM/VTWO；道指DIA或境内513400。VONE/VTHR/VTWO年费均0.06%，还要算点差、税和换汇。境内产品先核同步溢价，低费不抵消高溢价。

历史只有年末样本；道指、标普100、罗素1000/3000缺同口径连续历史。小盘10年另有亏损年，不能把正盈利年份分位当全历史。估值10月末/11月19日分口径标注，非实时行情。2026/11/21个人研究，非个性化建议。

#ETF研究 #道琼斯 #罗素2000 #美股宽基 #富时100 #纳斯达克100 #估值分析 #投资学习''' 
(OUT/'正文.txt').write_text(post,encoding='utf-8')
(OUT/'完整文案.md').write_text('# 小红书配套文案\n\n标题备选：\n- 英美宽基这么多，该怎么选？\n- 富时便宜，纳指一定贵吗？\n- 买纳指前，先算这笔溢价账\n\n'+post+'\n\n完整研究：https://lucky-xing.github.io/finance/sectors/ftse-sp-nasdaq-100-2026-11.html\n',encoding='utf-8')
with zipfile.ZipFile(OUT/'全球100指数小红书图文.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[OUT/'正文.txt',OUT/'完整文案.md']:z.write(p,p.name)
sheet=Image.new('RGB',(1890,720),BG)
for i,p in enumerate(files):im2=Image.open(p);im2.thumbnail((270,360));sheet.paste(im2,((i%7)*270,(i//7)*360))
sheet.save(OUT/'contact-sheet.jpg',quality=94)
# Reuse the inspected gallery shell, keeping full-size viewing, download and copy.
old=ROOT/'outputs/xiaohongshu-healthcare/index.html'
s=old.read_text(encoding='utf-8')
cards=''.join(f'<article><a href="{p.name}" class="zoom" data-index="{i}"><img src="{p.name}" alt="第{i+1}页：{p.stem[3:]}" loading="{"eager" if i==0 else "lazy"}" width="1080" height="1440"></a><div><span>{i+1:02d} / {p.stem[3:]}</span><a href="{p.name}" download>下载PNG ↓</a></div></article>' for i,p in enumerate(files))
s=re.sub(r'<div class="grid">.*?</div><details',lambda m:'<div class="grid">'+cards+'</div><details',s,flags=re.S)
s=re.sub(r'<pre id="post">.*?</pre>',lambda m:'<pre id="post">'+html.escape(post)+'</pre>',s,flags=re.S)
s=re.sub(r'const images=\[.*?\];',lambda m:'const images='+json.dumps([p.name for p in files],ensure_ascii=False)+';',s)
s=s.replace('医药ETF · 小红书图文预览','全球100指数 · 小红书图文预览').replace('医药ETF，便宜了吗？','英美宽基这么多，该怎么选？').replace('医药ETF小红书图文.zip','全球100指数小红书图文.zip')
s=s.replace('对应研究v0.3；数据截至2026-11-18，制作于2026-11-20。图片为已核实研究的可视化，不是实时行情。','对应研究v1.1；新增道琼斯与罗素1000/2000/3000。估值10月末与11/19分口径标注，历史只有年末点。')
s=s.replace('https://lucky-xing.github.io/finance/sectors/healthcare-etf-2026-11.html?v=7cfac17','https://lucky-xing.github.io/finance/sectors/ftse-sp-nasdaq-100-2026-11.html')
s=s.replace('全球100指数 · 小红书图文预览','英美主要指数 · 小红书图文预览')
s=s.replace('1张封面＋9张正文图','1张封面＋13张正文图')
s=s.replace('未自动发布到小红书。海外只作小样本参照，样本不等于整个行业；保留图片脚注。','未自动发布到小红书。年末样本不等于连续分位；9个跨市场参照不是全球分位。请保留图片脚注。')
(OUT/'index.html').write_text(s,encoding='utf-8')
print('Generated 14 images and gallery:',OUT)
