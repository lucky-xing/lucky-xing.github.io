from pathlib import Path
from bs4 import BeautifulSoup
import json,re
P=Path('work/global100')
for k in ['isf','qqqm','ndx-trailing','ndx-seriesjs']:
 t=(P/(k+('.js' if k.endswith('js') else '.html'))).read_text(encoding='utf-8')
 print('\n'+k)
 if k=='isf':
  for pat in ['csv','ajax','HSBA','Astra','holdings']:
   matches=list(re.finditer(pat,t,re.I));print(pat,len(matches))
   for m in matches[:3]: print(t[max(0,m.start()-100):m.start()+230])
 elif k=='qqqm':
  s=BeautifulSoup(t,'html.parser')
  for table in s.find_all('table'):
   tx=table.get_text(' | ',strip=True)
   if 'NVIDIA' in tx or 'Apple' in tx or 'Security' in tx: print(tx[:4000])
 else:
  for pat in ['data','nasdaq','series','fetch','\.json']:
   for m in list(re.finditer(pat,t,re.I))[:7]:print(t[max(0,m.start()-90):m.start()+160])
a=json.loads((P/'ndx-forward.json').read_text());print('HISTORY LAST',a['history'][-5:]);print('DAILY LAST',a['daily'][-5:])
print((P/'siblis-ndx.txt').read_text(encoding='utf-8')[1800:10000])
