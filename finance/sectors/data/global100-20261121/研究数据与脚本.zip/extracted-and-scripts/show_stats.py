from pathlib import Path
from pypdf import PdfReader
P=Path('work/global100')
t='\n'.join(p.extract_text() for p in PdfReader(P/'efunds-summary.pdf').pages);(P/'efunds-summary.txt').write_text(t,encoding='utf-8')
for line in t.splitlines():
 if any(k in line for k in ['管理费','托管费','0.50','0.10','综合费']):print(line)
for p in sorted(P.glob('stats-*.json')):
 import json
 d=json.loads(p.read_text(encoding='utf-8'));ks=['Market Cap','Enterprise Value','PE Ratio','Forward PE','P/FCF Ratio','Free Cash Flow','Operating Cash Flow','Capital Expenditures','Return on Equity (ROE)','Return on Invested Capital (ROIC)','PB Ratio','FCF Yield','Dividend Yield','Revenue Growth (YoY)','Earnings Growth (YoY)'];print(p.stem,{k:d[k] for k in ks if k in d})
