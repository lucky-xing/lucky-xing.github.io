from pathlib import Path
from bs4 import BeautifulSoup
import json,re
P=Path('work/global100')
for k in ['isf','oef']:
 s=BeautifulSoup((P/(k+'.html')).read_text(encoding='utf-8'),'html.parser')
 print(k)
 for sc in s.find_all('script',type='application/ld+json'):
  try:
   a=json.loads(sc.string or sc.get_text())
   def walk(o):
    if isinstance(o,dict):
     if o.get('@type') in ['DataFeed','ItemList','Dataset','Table']:print(json.dumps(o)[:500])
     for key,v in o.items():
      if key in ['topHoldings','holdings','holdingsData']:print(key,str(v)[:2000])
      walk(v)
    elif isinstance(o,list):
     for v in o:walk(v)
   walk(a)
  except:pass
 for m in list(re.finditer('holdingsTable|holdingsData|fundHoldings|csvUrl|ajaxUrl|ajaxTarget',str(s),re.I))[:6]:print(str(s)[max(0,m.start()-100):m.start()+400])
import pymupdf
for k in ['oef-factsheet','isf-factsheet','qqqm-factsheet','efunds-summary']:
 t='\n'.join(p.get_text() for p in pymupdf.open(P/(k+'.pdf')));(P/(k+'.txt')).write_text(t,encoding='utf-8')
 print(k, t[t.find('TOP 10'):t.find('TOP 10')+1800] if 'TOP 10' in t else t[-2000:] if k=='qqqm-factsheet' else '')
