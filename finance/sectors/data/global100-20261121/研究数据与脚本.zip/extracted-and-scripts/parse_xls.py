from pathlib import Path
import xml.etree.ElementTree as ET,json
P=Path('work/global100');root=ET.fromstring((P/'isf-download.xls').read_bytes());ns={'s':'urn:schemas-microsoft-com:office:spreadsheet'}
for ws in root.findall('s:Worksheet',ns):
 rows=[]
 for r in ws.findall('.//s:Row',ns):
  vals=[''.join(c.itertext()) for c in r.findall('s:Cell',ns)];rows.append(vals)
 name=ws.attrib.get('{urn:schemas-microsoft-com:office:spreadsheet}Name');print(name,len(rows));print(rows[:4])
 if 'hold' in name.lower():
  (P/'isf-holdings-extracted.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8');print(rows[:15])
