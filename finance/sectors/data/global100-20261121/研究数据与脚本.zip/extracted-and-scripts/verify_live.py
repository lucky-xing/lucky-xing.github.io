import requests,json
from urllib.parse import quote
base='https://lucky-xing.github.io/finance/sectors/'
for path in ['ftse-sp-nasdaq-100-2026-11.html?v=97836ae','xiaohongshu/global100-20261121/','data/global100-20261121/calculations.json','xiaohongshu/global100-20261121/'+quote('全球100指数小红书图文.zip')]:
 r=requests.get(base+path,timeout=30);r.raise_for_status();print(r.status_code,len(r.content),path)
 if path.endswith('calculations.json'):assert abs(r.json()['overlap']['minimumWeights']-55.05)<.0001
