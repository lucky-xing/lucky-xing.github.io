from pathlib import Path
from bs4 import BeautifulSoup
import json
P=Path('work/global100')
s=BeautifulSoup((P/'isf.html').read_text(encoding='utf-8'),'html.parser')
for el in s.find_all('walrus-render-on-client'):
 if el.get('componentkey')=='HoldingsTable':print(el.get('componentprops')[:6500])
from pypdf import PdfReader
for k in ['oef-factsheet','isf-factsheet','qqqm-factsheet','efunds-summary']:
 t='\n'.join(p.extract_text() for p in PdfReader(P/(k+'.pdf')).pages);(P/(k+'.txt')).write_text(t,encoding='utf-8');print(k,t[:600] if k!='isf-factsheet' else t[5000:7800])
