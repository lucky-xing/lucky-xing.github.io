from pathlib import Path
p=Path('work/global100/analyze.py')
s=p.read_text(encoding='utf-8-sig');s=s.replace("companies.append(r)","""soup=BeautifulSoup((P/f'stats-{t}.html').read_text(encoding='utf-8'),'html.parser').get_text(' ',strip=True)
 import re
 m=re.search(r'Nov \\d{1,2}, 2026, \\d{1,2}:\\d{2} (?:AM|PM) EST',soup);r['pageQuoteTime']=m.group(0) if m else None
 if t in ['aapl','msft','nvda','amzn','googl','meta']:
  row=next(x for x in json.loads((P/'oef-equities.json').read_text()) if x['Ticker']==t.upper())
  r['rawPageCap']=r['cap'];r['approxTotalShares']=num(d['Shares Outstanding']);r['close19']=float(row['Price']);r['cap']=r['approxTotalShares']*r['close19'];r['fcfYield']=100*r['fcf']/r['cap'];r['valuationNote']='19 Nov official ETF constituent closing price x rounded current total company shares; approximate cap, no index aggregation'
 companies.append(r)""")
p.write_text(s,encoding='utf-8')
