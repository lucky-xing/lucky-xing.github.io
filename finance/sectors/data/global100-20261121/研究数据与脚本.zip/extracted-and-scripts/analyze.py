from pathlib import Path
import json,numpy as np,csv,io,xml.etree.ElementTree as ET
from bs4 import BeautifulSoup
P=Path('work/global100');O=Path('outputs/global100');O.mkdir(exist_ok=True)
# Published annual observations: do not invent monthly history.
s=BeautifulSoup((P/'siblis-ftse.html').read_text(encoding='utf-8'),'html.parser')
a=[]
for tr in s.find_all('table')[1].select('tbody tr'):
 c=[x.get_text(' ',strip=True) for x in tr.find_all(['td','th'])]
 if c:a.append({'date':'2026-10-31' if c[0]=='Oct 2026' else c[0][:4]+'-12-31','pe':float(c[1]),'fpe':float(c[2]),'cape':float(c[3])})
s=BeautifulSoup((P/'siblis-ndx.html').read_text(encoding='utf-8'),'html.parser');b=[]
for tr in s.find_all('table')[1].select('tbody tr'):
 c=[x.get_text(' ',strip=True) for x in tr.find_all(['td','th'])]
 if c:b.append({'date':'2026-10-31' if c[0]=='Oct 2026' else c[0][:4]+'-12-31','pe':float(c[2])})
for arr in [a,b]:arr.sort(key=lambda x:x['date'])
def stats(arr,key,current,years,end='2026-10-31'):
 start=str(int(end[:4])-years)+end[4:];hist=[x[key] for x in arr if start<=x['date']<end];return {'window':years,'start':start,'end':end,'N':len(hist),'current':current,'percentile':100*sum(v<=current for v in hist)/len(hist),'p20':float(np.quantile(hist,.2)),'median':float(np.median(hist)),'p80':float(np.quantile(hist,.8))}
res={'date':'2026-11-21','valuationDate':'2026-10-31','ftseAnnual':a,'ndxAnnual':b,'annualStats':{}}
for name,arr,cols in [('ftse',a,['pe','fpe','cape']),('ndx',b,['pe'])]:
 for key in cols:res['annualStats'][name+'-'+key]=[stats(arr,key,arr[-1][key],y) for y in [3,5,10]]
# Consistent forward history ends 5 Aug; daily method is separate and never spliced.
f=json.loads((P/'ndx-forward.json').read_text());monthly={}
for r in f['history']:monthly[r['date'][:7]]=r
hist=list(monthly.values());end='2026-08-05';curr=f['history'][-1]['value']
res['ndxForwardHistoricalOnly']=[stats([{'date':x['date'],'pe':x['value']} for x in hist],'pe',curr,y,end) for y in [3,5,10]]
res['ndxForwardDaily']={'last':f['daily'][-1],'first':f['daily'][0],'N':len(f['daily']),'pct':sum(x['value']<=f['daily'][-1]['value'] for x in f['daily'])/len(f['daily'])*100,'warning':'daily begins 2026-08-05; not comparable long-run percentiles'}
# Official holdings, preserve cash weights and label equity renormalization for HHI.
weights={};res['holdings']={}
for k in ['oef','iqq']:
 rows=json.loads((P/(k+'-equities.json')).read_text());weights[k]={r['Ticker']:float(r['Weight (%)']) for r in rows};v=list(weights[k].values());tot=sum(v);res['holdings'][k]={'N':len(v),'equityWeight':tot,'top10':sum(sorted(v,reverse=True)[:10]),'effectiveN':1/sum((x/tot)**2 for x in v),'top':[(r['Ticker'],float(r['Weight (%)'])) for r in rows[:10]]}
rows=json.loads((P/'isf-holdings-extracted.json').read_text());eq=[[c.strip() for c in r] for r in rows[3:] if len(r)>6 and r[4].strip()=='Equity'];weights['isf']={r[0]:float(r[6]) for r in eq};v=list(weights['isf'].values());tot=sum(v);res['holdings']['isf']={'N':len(v),'equityWeight':tot,'top10':sum(sorted(v,reverse=True)[:10]),'effectiveN':1/sum((x/tot)**2 for x in v),'top':[(r[0],float(r[6])) for r in eq[:10]]}
a1=weights['oef'];b1=weights['iqq'];inter=set(a1)&set(b1);res['overlap']={'N':len(inter),'minimumWeights':sum(min(a1[t],b1[t]) for t in inter),'oefCovered':sum(a1[t] for t in inter),'ndxCovered':sum(b1[t] for t in inter)}
# Cash flow units are USD in source; bank CFO is deliberately not used as equity cash flow.
def num(t):
 t=t.replace(',','').replace('%','');mul={'T':1e12,'B':1e9,'M':1e6}.get(t[-1:],1);return float(t[:-1] if mul!=1 else t)*mul
companies=[]
for t in ['aapl','msft','nvda','amzn','googl','meta','azn','shel','ul','rio','hsbc','bcs']:
 d=json.loads((P/f'stats-{t}.json').read_text());r={'ticker':t.upper(),'cap':num(d['Market Cap']),'pe':float(d['PE Ratio']),'pb':float(d['PB Ratio']),'roe':num(d['Return on Equity (ROE)'])}
 if t not in ['hsbc','bcs']:
  r.update(ocf=num(d['Operating Cash Flow']),capex=-num(d['Capital Expenditures']),fcf=num(d['Free Cash Flow']));r['fcfYield']=100*r['fcf']/r['cap']
 soup=BeautifulSoup((P/f'stats-{t}.html').read_text(encoding='utf-8'),'html.parser').get_text(' ',strip=True)
 import re
 m=re.search(r'Nov \d{1,2}, 2026, \d{1,2}:\d{2} (?:AM|PM) EST',soup);r['pageQuoteTime']=m.group(0) if m else None
 if t in ['aapl','msft','nvda','amzn','googl','meta']:
  row=next(x for x in json.loads((P/'oef-equities.json').read_text()) if x['Ticker']==t.upper())
  r['rawPageCap']=r['cap'];r['approxTotalShares']=num(d['Shares Outstanding']);r['close19']=float(row['Price']);r['cap']=r['approxTotalShares']*r['close19'];r['fcfYield']=100*r['fcf']/r['cap'];r['valuationNote']='19 Nov official ETF constituent closing price x rounded current total company shares; approximate cap, no index aggregation'
 companies.append(r)
res['companies']=companies;u=companies[:6];res['sixUS']={'cap':sum(x['cap'] for x in u),'fcf':sum(x['fcf'] for x in u),'ocf':sum(x['ocf'] for x in u),'capex':sum(x['capex'] for x in u)};res['sixUS']['fcfYield']=100*res['sixUS']['fcf']/res['sixUS']['cap'];res['sixUS']['capexToOcf']=100*res['sixUS']['capex']/res['sixUS']['ocf']
# Mature-market index samples, not adjusted industry peers.
peer=[('US',25.75,18.60),('Canada',20.69,15.95),('Australia',20.15,18.22),('Japan',18.06,14.73),('Netherlands',17.64,14.44),('Germany',17.46,14.66),('France',16.67,13.31),('Spain',15.01,11.84),('Italy',14.72,11.51)];res['matureSample']=peer
res['crossMarket']={'N':len(peer),'medianPe':float(np.median([x[1] for x in peer])),'medianFpe':float(np.median([x[2] for x in peer])),'ftsePePercentile':sum(x[1]<=14.87 for x in peer)/len(peer)*100,'ftseFpePercentile':sum(x[2]<=11.97 for x in peer)/len(peer)*100,'ndxPePercentile':sum(x[1]<=32.76 for x in peer)/len(peer)*100,'ftsePeDiscount':14.87/np.median([x[1] for x in peer])-1,'ndxVsFtsePe':32.76/14.87-1,'ndxVsFtseFpe':21.24/11.97-1}
(O/'calculations.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8')
for k in ['annualStats','holdings','overlap','sixUS','crossMarket','ndxForwardHistoricalOnly','ndxForwardDaily']:print(k,json.dumps(res[k],ensure_ascii=True))

