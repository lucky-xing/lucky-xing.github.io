from pathlib import Path
import requests,concurrent.futures
P=Path('work/global100')
urls={
'oef':'https://www.ishares.com/us/products/239723/ishares-sp-100-etf',
'isf':'https://www.ishares.com/uk/individual/en/products/251795/fund',
'qqqm':'https://www.invesco.com/us/en/financial-products/etfs/invesco-nasdaq-100-etf.html',
'ndx-forward':'https://charts.allofthesewords.com/nasdaq100-fwdpe-data.json',
'ndx-trailing':'https://chartinmotion.com/markets/nasdaq-100-pe/',
'trefis-oef':'https://www.trefis.com/data/companies/OEF',
'trefis-qqq':'https://www.trefis.com/data/companies/QQQ',
'trefis-isf':'https://www.trefis.com/data/companies/ISF',
'oef-factsheet':'https://www.blackrock.com/us/individual/literature/fact-sheet/oef-ishares-s-p-100-etf-fund-fact-sheet-en-us.pdf',
'isf-factsheet':'https://www.ishares.com/uk/individual/en/literature/fact-sheet/isf-ishares-core-ftse-100-ucits-etf-fund-fact-sheet-en-gb.pdf',
'ndx-factsheet':'https://indexes.nasdaq.com/docs/FS_NDX.pdf',
'qqqm-factsheet':'https://www.invesco.com/us-rest/contentdetail?contentId=3bb2c37291215710VgnVCM1000006e36b50aRCRD&dnsName=us',
}
def one(item):
 k,u=item
 try:
  r=requests.get(u,timeout=45);r.raise_for_status();ext='pdf' if r.content.startswith(b'%PDF') else 'json' if k=='ndx-forward' else 'html';(P/(k+'.'+ext)).write_bytes(r.content);return(k,r.status_code,len(r.content))
 except Exception as e:return(k,str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
 for a in ex.map(one,urls.items()):print(a)
