from pathlib import Path
from bs4 import BeautifulSoup
import json,re
P=Path('work/global100')
for k in ['trefis-oef','trefis-qqq','siblis-ftse','siblis-ndx','siblis-world','quotelinks-oef']:
 p=P/(k+'.html')
 if not p.exists():continue
 s=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser');(P/(k+'.txt')).write_text(s.get_text(' ',strip=True),encoding='utf-8')
 print('\n'+k)
 for t in s.select('table'):
  if any(x in t.get_text() for x in ['P/FCF','Trailing P/E','Forward P/E','trailing_pe']):print(t.get_text(' | ',strip=True)[:6500])
 if k.startswith('siblis'):
  print([(a['src']) for a in s.find_all('script',src=True)])
  print([(a.get('src','') or a.get('href','')) for a in s.find_all(['img','a']) if 'chart' in (a.get('src','')+a.get('href',''))][:8])
for k in ['oef-holdings.csv','isf-holdings.csv','qqqm-holdings.csv','qqqm-holdings.html']:
 p=P/k
 if p.exists():print(k,p.read_text(encoding='utf-8-sig')[:1800])
