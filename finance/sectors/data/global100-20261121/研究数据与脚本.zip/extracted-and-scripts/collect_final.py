from pathlib import Path
import requests,concurrent.futures,json
from bs4 import BeautifulSoup
P=Path('work/global100')
urls={
'iqq':'https://www.ishares.com/us/products/351653/ishares-nasdaq-100-etf',
'iqq-holdings':'https://www.ishares.com/us/products/351653/ishares-nasdaq-100-etf/latest-holdings.csv',
'isf-download':'https://www.blackrock.com/varnish-api/uk-retail01-product-data/product-data/api/v1/get-fund-document?appType=PRODUCT_PAGE&appSubType=ISHARES&targetSite=ishares-uk&locale=en_GB&portfolioId=251795&component=fundDownloadV2&userType=individual',
'qndx':'https://www.ssga.com/us/en/individual/etfs/state-street-spdr-portfolio-nasdaq-100-etf-qndx',
'siblis-countries':'https://siblisresearch.com/data/pe-ratios-by-country/',
}
urls.update({f'stats-{t}':f'https://stockanalysis.com/stocks/{t}/statistics/' for t in ['aapl','msft','nvda','amzn','googl','meta','azn','shel','ul','rio','hsbc','bcs']})
def one(item):
 k,u=item
 try:
  r=requests.get(u,timeout=40);r.raise_for_status();ext='csv' if k=='iqq-holdings' else 'xls' if k=='isf-download' else 'html';(P/(k+'.'+ext)).write_bytes(r.content)
  if k.startswith('stats-'):
   s=BeautifulSoup(r.content,'html.parser');d={}
   for tr in s.select('table tr'):
    c=tr.find_all(['td','th'])
    if len(c)==2:d[c[0].get_text(' ',strip=True)]=c[1].get_text(' ',strip=True)
   (P/(k+'.json')).write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
  return(k,len(r.content))
 except Exception as e:return(k,str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
 for a in ex.map(one,urls.items()):print(a)
