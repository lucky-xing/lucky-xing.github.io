from pathlib import Path
import requests,concurrent.futures,json
P=Path('work/global100')
urls={
'siblis-ftse':'https://siblisresearch.com/data/ftse-100-cape-pe-yield/',
'siblis-ndx':'https://siblisresearch.com/data/nasdaq-100-pe-ratio/',
'siblis-world':'https://siblisresearch.com/data/pe-ratios/',
'oef-holdings':'https://www.ishares.com/us/products/239723/ishares-s-p-100-etf/latest-holdings.csv',
'isf-holdings':'https://www.ishares.com/uk/individual/en/products/251795/ishares-core-ftse-100-ucits-etf/latest-holdings.csv',
'qqqm-holdings':'https://www.invesco.com/us/financial-products/etfs/holdings/main/holdings/0?ticker=QQQM',
'quotelinks-oef':'https://www.quotelinks.com/valuation/oef.html',
'ndx-seriesjs':'https://chartinmotion.com/assets/market-assets.js',
'efunds-summary':'https://static.cninfo.com.cn/finalpage/2026-08-11/1225467500.PDF',
'cxfund':'https://www.cxfund.com.cn/products/qdii/519981/index.html',
}
def one(item):
 k,u=item
 try:
  r=requests.get(u,timeout=40);r.raise_for_status();ext='pdf' if r.content.startswith(b'%PDF') else 'csv' if k.endswith('holdings') and not r.text.lstrip().startswith('<') else 'js' if k.endswith('js') else 'html';(P/(k+'.'+ext)).write_bytes(r.content);return(k,len(r.content),ext)
 except Exception as e:return(k,str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
 for x in ex.map(one,urls.items()):print(x)
