from pathlib import Path
p=Path('work/global100/build_report.py');s=p.read_text(encoding='utf-8');s=s.replace("if f.is_file() and f.suffix in ['.py','.json']:z.write(f,'extension/'+f.name)","if f.is_file() and f.suffix in ['.py','.json'] and f.name!='dia-raw-rows.json':z.write(f,'extension/'+f.name)");p.write_text(s,encoding='utf-8')
p=Path('work/global100/build_images.py');s=p.read_text(encoding='utf-8');s=s.replace("s=s.replace('1张封面＋9张正文图','1张封面＋13张正文图')","s=s.replace('全球100指数 · 小红书图文预览','英美主要指数 · 小红书图文预览')\ns=s.replace('1张封面＋9张正文图','1张封面＋13张正文图')");p.write_text(s,encoding='utf-8')
