from pathlib import Path
from bs4 import BeautifulSoup
import json,re
P=Path(__file__).parent
X=json.loads((P/'extension-calculations.json').read_text(encoding='utf-8'))
def table(head,rows,caption=''):
 return '<div class="table-scroll" tabindex="0"><table><caption>'+caption+'</caption><thead><tr>'+''.join('<th>'+str(x)+'</th>' for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(x)+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def sec(id,title,body):return '<section id="'+id+'"><h2>'+title+'</h2>'+body+'</section>'
def a(url,t):return '<a href="'+url+'" target="_blank" rel="noopener">'+t+'</a>'
def rchart():
 arr=X['r2000Annual'];y0=28;ch=210;mx=120;svg='<svg viewBox="0 0 960 300" role="img" aria-label="罗素2000年末TTM PE快照，2020年整体亏损无有效PE"><title>罗素2000年末TTM PE，亏损年份断线</title>'
 for v in [0,30,60,90,120]:
  y=y0+ch*(1-v/mx);svg+=f'<line x1="55" y1="{y}" x2="910" y2="{y}" stroke="#ffffff22"/><text x="8" y="{y+4}">{v}</text>'
 run=[]
 for i,row in enumerate(arr):
  x=55+850*i/(len(arr)-1)
  svg+=f'<text x="{x-19}" y="279">{row["date"][:4] if i<10 else "26/10"}</text>'
  if row['pe'] is None:
   if run:svg+='<polyline points="'+' '.join(run)+'" fill="none" stroke="#efbc83" stroke-width="3"/>';run=[]
   svg+=f'<text x="{x-22}" y="245">亏损</text>';continue
  y=y0+ch*(1-row['pe']/mx);run.append(f'{x:.1f},{y:.1f}')
  svg+=f'<circle cx="{x}" cy="{y}" r="4" fill="#efbc83"/><text x="{x-22}" y="{y-12}">{row["pe"]:.2f}</text>'
 if run:svg+='<polyline points="'+' '.join(run)+'" fill="none" stroke="#efbc83" stroke-width="3"/>'
 return svg+'</svg>'
def augment(page):
 s=BeautifulSoup(page,'html.parser')
 s.title.string='英美主要股票指数：富时、标普、纳指、道琼斯与罗素 · Lighting Future'
 s.find('meta',attrs={'name':'description'})['content']='富时、标普、纳指、道琼斯与罗素系列的实际估值、亏损处理、年末历史、持仓重叠及ETF选择；附14张小红书图集。'
 s.find('h1').clear();s.find('h1').append(BeautifulSoup('英美主要股票指数<br>估值、分散与ETF选择','html.parser'))
 s.select_one('.draft-tag').string='v1.1 / 新增道琼斯与罗素1000、2000、3000'
 h1=s.find('h1');h1.find_next_sibling('p').string='富时100、标普100、纳斯达克100、道琼斯与罗素系列：从海外价值到美国全市场'
 s.select_one('.meta').string='2026-11-21扩展｜同源跨市场估值2026-10末｜新增管理人估值及股票持仓11/19｜历史仅年末样本，非连续分位'
 # Put the expanded scope and changed core allocation decision before the original three-way analysis.
 c=s.find(id='conclusions')
 intro='''<div class="preview-banner">v1.1更新：补充道琼斯工业平均指数、罗素1000/2000/3000，新增实际估值、罗素2000亏损处理与年末历史、4只代理完整股票持仓及产品成本。原三类100指数分析保留，更新整体配置判断。</div>
<p><strong>扩大范围后，研究顺序应调整：</strong>若目标是美股核心配置，先比较罗素3000/1000或标普500等跨行业宽基；纳指作为成长倾斜、罗素2000作为小盘倾斜，道指作为特定蓝筹风格。新增指数并没有改变“富时可分散美国成长”的判断，但不再把OEF当美股核心的默认候选。</p>'''
 c.find('h2').insert_after(BeautifulSoup(intro,'html.parser'))
 extra=table(['新增对象','11/19管理人快照','当前估值判断','用途'],[
 ['道琼斯 / DIA','FY1预期PE17.78；PB5.02','相对温和，但内在低估未证实；缺可比历史分位','蓝筹风格；30股价格加权，有明确偏好再配置'],
 ['罗素1000 / IWB','管理人PE27.04；PB5.02','当前倍数仍要求盈利支撑；自身历史位置不确定','美国大中盘核心候选，先比较更低费同指数工具'],
 ['罗素3000 / IWV','管理人PE26.65；PB4.74','比1000略低，不等于更便宜一大截；历史位置不确定','美国全市场核心候选，仍由大盘主导'],
 ['罗素2000 / IWM','管理人PE17.74；PB2.00；10末含亏损TTM35.77','整体不认定便宜；“盈利公司便宜”不等于整个小盘便宜','周期、融资与盈利修复的卫星工具'],
 ],'新增估值：DIA为FY1预测调和平均，IWB/IWV/IWM为iShares展示PE；不可混成统一TTM榜。原富时/纳指共同截面仍为10月末。')
 c.append(BeautifulSoup(extra,'html.parser'))
 links=X['sources']
 dow=sec('dow','道琼斯：30股价格加权，究竟适合什么策略',
 '''<p>本报告中的道琼斯特指<strong>道琼斯工业平均指数（DJIA）</strong>，不泛指所有“道琼斯”品牌指数。它选择30家美国蓝筹，按股价加权，排除运输与公用事业板块；并非美国市值最大的30家公司。“工业”是历史名称，当前包含金融、科技、医疗与消费等。</p>
<div class="callout">价格加权：一股股价更高，就可能拿到更高权重。DIA 11/19高盛约10.25%、苹果约4.22%；不是因为高盛市值大于苹果。拆股可改变相对权重，指数除数调整避免仅因拆股造成机械跳点。</div>'''+
 table(['11/19代理','FY1预期PE','PB','前三大行业','前十大/股票仓位'],[['DIA','17.78','5.02','金融27.50%、信息技术18.10%、医疗14.15%',f"{X['funds']['dia']['top10']:.2f}%"]])+
 '''<p>FY1 PE采用成分预测当年盈利的加权调和平均，管理人说明包含正负异常值；不同于未来12个月NTM，更不同于剔亏TTM。PB5.02在混合行业中仅作辅助，金融需结合ROE/资本，工业需结合中周期利润和资本开支。不能把17.78直接与纳指10月正常化TTM32.76比较，宣称道指“便宜近一半”。</p>
<p><strong>判断：</strong>预期盈利倍数相对温和，可作为蓝筹/较低科技权重的风格候选；尚不能证明绝对低估。前十大超过股票仓位一半，价格加权有明显选择偏好，不优先用它代表完整美国市场。没有取得同口径3/5/10年FY1 PE与FCF历史，历史位置不确定，不以指数点位或旧报道补出分位。</p>'''+
 '<p class="note">规则：'+a('https://www.spglobal.com/spdji/en/indices/equity/dow-jones-industrial-average/','S&P DJIA')+'；快照、估值定义与行业：'+a(links['dia'],'DIA官方页面')+'；前十大股票权重由官方Excel复算，已剔现金。</p>')
 russell=sec('russell','罗素系列：3000是全市场，1000和2000是不同规模部分',
 table(['指数','覆盖与权重','主要业务/收益驱动','关键风险'],[
 ['罗素3000','约3,000家美国公司，约98%可投资市值；流通市值加权','全市场盈利增长，实际大盘占比高','并非大中小各占1/3，仍会受巨头与科技影响'],
 ['罗素1000','3000中规模较大的约1,000家公司，覆盖大中盘','成熟龙头和部分中盘增长','与标普100、纳指大量重复，不自动增加组合分散'],
 ['罗素2000','3000中规模较小的约2,000家公司','美国小盘盈利、融资条件与经济周期','亏损、再融资、信用和流动性风险；小市值不等于价值股'],
 ['1000 Growth / Value','1000的成长/价值风格切片，不是额外国家市场','成长或价值因子暴露','部分公司可按概率分配到两种风格，不能把两个名单当绝对互斥'],
 ])+
 '''<p>在指数层面，罗素1000与2000构成3000的规模划分；ETF可能采用抽样、持有现金或临时证券，实际持仓数不必正好等于名称。不能按“1000:2000”的股票数量把资金配成1:2，声称复制3000。</p>
<p><strong>规则更新：</strong>2026年起改为半年重构；本次12月重构预计于<strong>2026-12-11收盘后</strong>生效，排名日为10月末。按最新公告使用12月安排，不沿用早期曾公布的11月方案。规模迁移、IPO纳入和重构交易会改变估值/换手，因此历史估值不能用今天成分直接回填。</p>'''+
 table(['基金 / 11/19','管理人PE','PB','近3年年化波动*','前三大股票行业**'],[
 ['IWB / 1000','27.04','5.02','12.45%','信息技术33.79%、金融12.86%、医疗10.54%'],
 ['IWV / 3000','26.65','4.74','12.59%','信息技术32.96%、金融13.11%、医疗10.95%'],
 ['IWM / 2000','17.74','2.00','18.91%','医疗20.84%、金融19.64%、工业13.38%'],
 ])+
 '''<p>*波动来自管理人截至10/31的历史3年统计，不是未来风险承诺。**行业由11/19股票市值重建并归一化，不含现金。罗素2000虽然头部权重低，但历史波动明显高于1000/3000，分散个股不等于消除经济周期风险。</p>
<p><strong>当前判断：</strong>1000与3000更适合作为美国核心配置的研究起点；27倍左右管理人PE并非深度价值定价，历史低估程度仍不确定。2000需单独看下节的亏损与融资条件，不能以17.74倍直接排为最便宜。Growth/Value同源10末预期PE为21.51/16.21倍，体现风格差异；不是两个可不计风险互换的资产。</p>'''+
 '<p class="note">原始页面：'+a(links['iwb'],'IWB')+'、'+a(links['iwv'],'IWV')+'、'+a(links['iwm'],'IWM')+'；规则与日期：'+a(links['russellRules'],'LSEG最新方法')+'、'+a(links['reconstitution'],'12月重构公告')+'。</p>')
 hist=table(['窗口 / 当前35.77','有效PE样本N','年末参照位置','样本PE中位','20 / 80参考','亏损年份'],[[f"近{r['years']}年",r['N'],f"{r['percentile']:.1f}%",f"{r['median']:.2f}",f"{r['p20']:.2f} / {r['p80']:.2f}",f"{r['negativeExcluded']}个无有效PE"] for r in X['annualStats']])
 losses=sec('russell-valuation','罗素2000估值实算：为什么17倍和35倍可能同时出现',
 '''<div class="warning">亏损公司不能从投资组合中消失，却可能从某些PE展示口径里被剔除。较低的“盈利公司PE”，不是包含全部亏损后的整体价格。</div>'''+
 table(['口径','日期','PE / 辅助信息','如何读'],[
 ['IWM管理人展示PE','11/19','17.74；PB2.00','按美国iShares事实表定义，有剔负盈利及PE封顶等处理；不能当含亏总市值/总净利'],
 ['Siblis正常化整体TTM','10/31','35.77','公司亏损抵减组合盈利，分母更小；与管理人PE日期、算法均不同'],
 ['Siblis整体预期PE','10/31','23.14','依赖预测盈利修复，非已实现收益'],
 ['Siblis CAPE','10/31','60.43','10年实际盈利平滑有助观察分母异常，但受成分变迁与结构增长影响'],
 ])+
 '''<p>示意：假设总市值2,000、盈利公司赚100、亏损公司亏40，忽略亏损会看到20倍，而完整组合为2,000/(100−40)＝33.3倍。这是解释机制的假设例子，不是IWM实际亏损金额。没有完成本期全部成分的统一报表归集，故不公布未经核实的亏损公司比例或市值权重。</p>
<p>这里没有简单“用CAPE替代PE”：小盘主指标应为<strong>含亏损的正常化盈利收益率＋盈利覆盖/修复</strong>，辅以非金融公司现金流/利息覆盖、债务到期和银行资本。35.77倍对应正常化盈利收益率约2.80%，预测23.14倍对应约4.32%，增长兑现决定差异。3年EPS年化增长仅2.9%（同源10月），不支持仅凭便宜叙事忽略盈利质量。</p>'''+hist+
 '<div class="chart"><h3>罗素2000 TTM PE：亏损年份断线，保留分母风险</h3>'+rchart()+'<p class="caption">2016–2025年末＋2026-10。2020整体正常化盈利为负，PE无有效经济含义，图中不填零、不连接缺口。当前点不计入分位分母；连线仅引导阅读。</p></div>'+
 '''<p>同源年末样本：近3/5/10年分别3/5/9个有效PE点，10年另有2020亏损点。有效PE年末参照位置100%/60%/33.3%，不等于连续历史分位；尤其10年统计排除了一个亏损年，是<strong>条件于正盈利年份</strong>的排序，不能用33.3%认定整体低估。</p>
<p>同源成熟市场粗对照：35.77倍高于原报告9个其他发达市场国家指数TTM（样本位置100%），比17.64倍中位高102.8%；它与其他国家宽基行业/规模不匹配，仅说明本次整体盈利分母没有显示普遍便宜，不是可直接兑现的溢价回归。未获得含亏损估值与海外同类小盘的完整同期历史，不能报“小盘全球分位”。</p>
<p><strong>结论：</strong>绝对低估不成立；正盈利年末历史位置较低也不够。利率下降若伴随软着陆、信用利差稳定、盈利改善，才有较好的小盘反转逻辑；衰退式降息可能同时损伤收入和融资。增加条件是含亏损盈利预期上修、利息覆盖改善且估值未扩张过快；信用利差走阔、再融资恶化或盈利下修时暂停。当前不发布未经统一价格/盈利映射验证的ETF目标价。</p>'''+
 '<p class="note">数据与方法：'+a(links['siblis-r2000'],'Siblis罗素2000')+'；展示PE定义参考'+a('https://www.blackrock.com/us/individual/literature/fact-sheet/iwm-ishares-russell-2000-etf-fund-fact-sheet-en-us.pdf','IWM事实表')+'。年末数值与图表为本研究复算。</p>')
 pairs=table(['11/19股票仓位内部比较','共同代码数','加权重叠','含义'],[[lab,X['pairs'][k]['N'],f"{X['pairs'][k]['overlap']:.2f}%",note] for k,lab,note in [
 ('iwb-iwv','1000 IWB × 3000 IWV','全市场与大中盘非常接近'),('iwb-oef','1000 IWB × 标普100 OEF','超大盘是大中盘中的重要部分'),('iwb-iqq','1000 IWB × 纳指 IQQ','加纳指主要增加成长权重'),('iwb-iwm','1000 IWB × 2000 IWM','规模划分不同，仍存在共同宏观风险'),('dia-iqq','道指 DIA × 纳指 IQQ','直接重复较少，但都属美国股票')]])
 allocation=sec('expanded-funds','扩展组合与ETF：先选核心，再决定风格倾斜',pairs+
 '''<p>本表Σmin(w₁,w₂)，按股票仓位归一化；iShares由逐股市值重建，避免小权重四舍五入累积偏差。DIA由官方权重剔现金后归一化。与原报告按净资产权重计算的55.05%不同，不能混用。代码重合不衡量收益相关性，现金、期货及交易替代不在此表。</p>'''+
 f'''<div class="callout">IWV股票仓位中，约<strong>{X['iwvSizeWeight']['inIwb']:.2f}%</strong>属于IWB所持证券，约<strong>{X['iwvSizeWeight']['inIwm']:.2f}%</strong>属于IWM所持证券。这是实际ETF样本穿透，非指数精确规模比例；IWV采用抽样，持股数量少于名称3000。新增很多小公司，未必增加很多小盘资金权重。</div>'''+
 table(['暴露 / 工具','年费率','本期选择与边界'],[
 ['道琼斯：DIA','0.16%','明确需要价格加权蓝筹风格时考虑；不是默认美股核心'],
 ['道琼斯：鹏华513400（境内QDII）','管理0.50%＋托管0.15%','境内候选；仍核同步溢价、点差与跟踪，本期未核当日真实溢价，不直接判可买'],
 ['罗素1000：IWB / VONE','0.15% / 0.06%','同指数长期成本优先比较VONE；较低费率不自动抵消更大的点差和换手成本'],
 ['罗素3000：IWV / VTHR','0.20% / 0.06%','全市场长期成本优先比较VTHR；与1000重复较多，通常无须都当独立核心'],
 ['罗素2000：IWM / VTWO','0.19% / 0.06%','长期买持先比较VTWO；交易/期权用途再看IWM的即时市场质量'],
 ])+
 '''<p>Vanguard费率为2026年官方降费文件与资料表确认；0.06%不是未经复核沿用的0.07%。IWM与VTWO年费差0.13个百分点，同额不变的10万美元约差130美元/年；若换仓新增一次性0.20%成本，约1.54年费用差抵消，未计税与复利。不能只为省费而忽略实现税负或交易成本。</p>
<p><strong>策略结论：</strong>美国核心配置先比较3000/1000及标普500；传统价值/分红研究仍可看富时，但不能把道指等同严格价值因子。成长倾斜用纳指，小盘反转用2000，后两者不宜仅因“增长快/跌得多”取代核心。1000/3000自身历史估值缺口保留；2000有历史参照但没有足够安全边际证据；道指不因FY1倍数较低自动排第一。</p>
<p>没有核实当前境内直接跟踪罗素1000/2000/3000的可交易公募产品，本版不将历史申报、拟发行产品写成已可买。上述罗素ETF均为境外上市，账户准入、换汇、税与费用规则需按实际渠道核实；也不能把港股通当作可买美股ETF的通道。</p>'''+
 '<p class="note">费率原始文件：'+a(links['vanguardFees'],'Vanguard 2026官方降费表')+'；境内道指：'+a(links['domesticDow'],'鹏华2026-09产品概要（公开转载）')+'。DIA和iShares费率见各官方产品页面。所有策略选择为本研究条件判断。</p>')
 fragment=BeautifulSoup(dow+russell+losses+allocation,'html.parser')
 target=s.find(id='universe')
 for el in reversed(list(fragment.contents)):
  if getattr(el,'name',None):target.insert_after(el)
 toc=s.select_one('.toc')
 for id,label in [('dow','道琼斯'),('russell','罗素体系'),('russell-valuation','小盘估值'),('expanded-funds','宽基与ETF')]:
  el=s.new_tag('a',href='#'+id);el.string=label;toc.append(el)
 # Sequential section numbers after inserting four integrated sections.
 cn=['一','二','三','四','五','六','七','八','九','十','十一','十二','十三','十四','十五','十六','十七']
 for n,section in enumerate(s.select('main > section')):
  h=section.find('h2');h.string=cn[n]+'、'+re.sub(r'^[一二三四五六七八九十]+、','',h.get_text())
 evidence=s.find(id='evidence')
 evidence.find('h2').insert_after(BeautifulSoup('<p class="warning">扩展部分采集于2026-11-21，新增ETF估值/股票持仓仍统一11/19，罗素2000跨市场与历史采用10月末同源数据；没有用11/20净值变化去更新11/19估值。道指、罗素1000及3000同口径估值历史仍缺，未编造分位。</p>','html.parser'))
 for url,label in [(links[k],k) for k in ['dia','iwb','iwm','iwv','russellRules','reconstitution','vanguardFees']]:
  li=s.new_tag('li');aa=s.new_tag('a',href=url);aa.string=label;li.append(aa);evidence.select_one('details ol').append(li)
 # New downloadable numerical evidence in the existing evidence directory.
 p=s.new_tag('p');p.append(BeautifulSoup('<a href="data/global100-20261121/extension-calculations.json">道琼斯与罗素扩展计算JSON ↓</a>；数值与采集/复算脚本已加入原下载包。','html.parser'));evidence.append(p)
 return '\n'.join(line.rstrip() for line in str(s).splitlines())+'\n'
