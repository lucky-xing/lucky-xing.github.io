from pathlib import Path
import zipfile,xml.etree.ElementTree as E
p=Path('work/global100/extension/dia-holdings.xlsx');z=zipfile.ZipFile(p);ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
ss=[]
if 'xl/sharedStrings.xml' in z.namelist():ss=[''.join(x.itertext()) for x in E.fromstring(z.read('xl/sharedStrings.xml'))]
root=E.fromstring(z.read('xl/worksheets/sheet1.xml'));rows=[]
for row in root.findall('.//s:row',ns):
 vals=[]
 for c in row.findall('s:c',ns):
  v=c.find('s:v',ns);val=v.text if v is not None else ''.join(c.find('s:is',ns).itertext()) if c.find('s:is',ns) is not None else ''
  if c.get('t')=='s':val=ss[int(val)]
  vals.append(val)
 rows.append(vals)
print(rows[:12]);print(rows[-5:])
import json
Path('work/global100/extension/dia-raw-rows.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
