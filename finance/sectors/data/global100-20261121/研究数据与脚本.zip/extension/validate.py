from pathlib import Path
from bs4 import BeautifulSoup
import json,zipfile
p=Path('outputs/global100');s=BeautifulSoup((p/'ftse-sp-nasdaq-100-2026-11.html').read_text(encoding='utf-8'),'html.parser')
x=json.loads(Path('work/global100/extension/extension-calculations.json').read_text(encoding='utf-8'))
assert x['funds']['dia']['N']==30
assert x['annualStats'][-1]['N']==9 and x['annualStats'][-1]['negativeExcluded']==1
assert abs(x['iwvSizeWeight']['inIwb']+x['iwvSizeWeight']['inIwm']-100)<.001
assert x['pairs']['iwb-iwm']['N']==0
assert x['funds']['iwm']['top10']<5 and x['funds']['dia']['top10']>50
for id in ['dow','russell','russell-valuation','expanded-funds']:assert s.find(id=id)
g=BeautifulSoup((p/'xiaohongshu/index.html').read_text(encoding='utf-8'),'html.parser');assert len(g.select('article img'))==14
z=zipfile.ZipFile(p/'xiaohongshu/全球100指数小红书图文.zip');assert len([n for n in z.namelist() if n.endswith('.png')])==14
assert 'v1.1' in g.get_text()
print('Validated holdings scope, size weight totals, loss-year exclusion, all 4 new sections, 14-image gallery and ZIP.')
