from pathlib import Path
from pypdf import PdfReader
p=Path('work/global100/extension/iwm-sheet.pdf');t=' '.join(p.extract_text() for p in PdfReader(p).pages);i=t.find('Negative earnings');print(t[max(0,i-160):i+230])
p=Path('work/global100/build_report.py');s=p.read_text(encoding='utf-8-sig');s=s.replace("(O/slug).write_text(page,encoding='utf-8')","import runpy\npage=runpy.run_path(str(P/'extension/augment_report.py'))['augment'](page)\n(O/slug).write_text(page,encoding='utf-8')")
s=s.replace("for f in [O/'calculations.json',O/'sources.json']:z.write(f,f.name)","for f in [O/'calculations.json',O/'sources.json']:z.write(f,f.name)\n for f in (P/'extension').iterdir():\n  if f.is_file() and f.suffix in ['.py','.json']:z.write(f,'extension/'+f.name)")
p.write_text(s,encoding='utf-8')
