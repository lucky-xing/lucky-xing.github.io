from pathlib import Path
from bs4 import BeautifulSoup
import re,json
P=Path('work/global100/extension')
for k in ['iwb','iwm','iwv','dia','siblis-r2000']:
 p=P/(k+'.html')
 if not p.exists():continue
 s=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser');t=s.get_text(' ',strip=True);print('\n'+k)
 for key in ['Portfolio Characteristics','Fund Characteristics','Price/Earnings Ratio FY1','Gross Expense Ratio','P/E Ratio','P/B Ratio','Number of Holdings','30 Day Median Bid/Ask Spread']:
  i=t.find(key);print(t[i:i+340] if i>=0 else '')
 for ta in s.find_all('table'):
  if any(x in ta.get_text() for x in ['Top Holdings','Weight','Month','Negative','Trailing P/E']):print(ta.get_text(' | ',strip=True)[:3500])
 if k=='dia':
  print('Holdings downloads',[(a.get_text(' ',strip=True),a.get('href')) for a in s.find_all('a',href=True) if any(x in a['href'] for x in ['holdings','xlsx','fact'])][:12])
 if k=='siblis-r2000':print(t[900:3700])
