from pathlib import Path
from bs4 import BeautifulSoup
p=Path('outputs/global100/ftse-sp-nasdaq-100-2026-11.html');s=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser')
print('Sections:',len(s.select('section')),'Charts:',len(s.select('svg')))
print([x.get_text() for x in s.select('section h2')])
print('Figures:',[(x['id'],len(x.select('table'))) for x in s.select('main > section')])
