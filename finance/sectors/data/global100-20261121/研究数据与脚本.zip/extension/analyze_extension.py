from pathlib import Path
from bs4 import BeautifulSoup
import json,re,csv,io,statistics
P=Path(__file__).parent
ROOT=P.parent
out={'date':'2026-11-21','holdingsDate':'2026-11-19','funds':{},'weights':{},'pairs':{}}
for k in ['iwb','iwm','iwv']:
 t=BeautifulSoup((P/(k+'.html')).read_text(encoding='utf-8'),'html.parser').get_text(' ',strip=True)
 def val(pattern):
  m=re.search(pattern,t);return float(m.group(1).replace(',','')) if m else None
 out['funds'][k]={'pe':val(r'P/E Ratio ([\d.]+) as of Nov 19, 2026'),'pb':val(r'P/B Ratio ([\d.]+) as of Nov 19, 2026'),'vol3y':val(r'Standard Deviation \(3y\) ([\d.]+)%'),'expense':val(r'Expense Ratio:Fees as stated in the prospectus ([\d.]+)%')}
 text=(P/(k+'-holdings.csv')).read_text(encoding='utf-8-sig');assert 'Nov 19, 2026' in text[:120]
 rows=[r for r in csv.DictReader(io.StringIO(text[text.index('Ticker,'):])) if r.get('Asset Class')=='Equity']
 
 def mv(r):return float(r['Market Value'].replace(',','')) if r['Market Value'] not in ['-',''] else 0
 equitymv=sum(mv(r) for r in rows)
 out['funds'][k]['weightDefinition']='equity market value / total equity market value; cash excluded, no rounded weight accumulation'
 out['funds'][k]['zeroMarketValueCount']=sum(mv(r)==0 for r in rows)
 for r in rows:r['Weight (%)']=str(100*mv(r)/equitymv)
 weights={r['Ticker']:float(r['Weight (%)']) for r in rows};out['weights'][k]=weights
 sectors={}
 for r in rows:sectors[r['Sector']]=sectors.get(r['Sector'],0)+float(r['Weight (%)'])
 tot=sum(weights.values());out['funds'][k].update(N=len(rows),equityWeight=tot,top10=sum(sorted(weights.values(),reverse=True)[:10]),effectiveN=1/sum((w/tot)**2 for w in weights.values()),sectors=sectors)
 (P/(k+'-equities.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
rows=json.loads((P/'dia-raw-rows.json').read_text(encoding='utf-8'))
assert '19-Nov-2026' in rows[2][1]
hold=[r for r in rows[4:] if len(r)>7 and r[1] not in ['', '-'] and r[4] and r[7]=='USD']
den=sum(float(r[4]) for r in hold)
w={r[1]:100*float(r[4])/den for r in hold};out['weights']['dia']=w;tot=sum(w.values())
out['funds']['dia']={'fpeFy1':17.78,'pb':5.02,'expense':.16,'N':len(w),'top10':sum(sorted(w.values(),reverse=True)[:10]),'equityWeight':tot,'effectiveN':1/sum((v/tot)**2 for v in w.values()),'top':[(r[1],float(r[4])) for r in hold[:10]],'sectors':{'Financials':27.50,'Information Technology':18.10,'Health Care':14.15,'Industrials':13.25}}
for k in ['oef','iqq']:
 rows=json.loads((ROOT/(k+'-equities.json')).read_text(encoding='utf-8'));den=sum(float(r['Market Value'].replace(',','')) for r in rows);out['weights'][k]={r['Ticker']:100*float(r['Market Value'].replace(',',''))/den for r in rows}
for a,b in [('iwb','iwv'),('iwb','iwm'),('iwv','iwm'),('iwb','oef'),('iwb','iqq'),('iwm','iqq'),('dia','oef'),('dia','iqq')]:
 wa=out['weights'][a];wb=out['weights'][b];common=wa.keys()&wb.keys();out['pairs'][a+'-'+b]={'N':len(common),'overlap':sum(min(wa[t],wb[t]) for t in common),'aCovered':sum(wa[t] for t in common),'bCovered':sum(wb[t] for t in common)}
# Approximate size share within actual IWV basket. Individual ETF sampling means incomplete coverage.
out['iwvSizeWeight']={'inIwb':sum(w for t,w in out['weights']['iwv'].items() if t in out['weights']['iwb']),'inIwm':sum(w for t,w in out['weights']['iwv'].items() if t in out['weights']['iwm'])}
s=BeautifulSoup((P/'siblis-r2000.html').read_text(encoding='utf-8'),'html.parser');arr=[]
for tr in s.find_all('table')[1].select('tbody tr'):
 c=[x.get_text(' ',strip=True) for x in tr.find_all(['td','th'])]
 if not c:continue
 arr.append({'date':'2026-10-31' if c[0]=='Oct 2026' else c[0][:4]+'-12-31','pe':None if c[3]=='Negative' else float(c[3]),'earningsNegative':c[3]=='Negative'})
arr.sort(key=lambda x:x['date']);out['r2000Annual']=arr
out['r2000Valuation']={'pe':35.77,'fpe':23.14,'cape':60.43,'epsGrowth1y':9.7,'epsGrowth3y':2.9}
out['annualStats']=[]
for y in [3,5,10]:
 rows=[r for r in arr if f'{2026-y}-10-31'<=r['date']<'2026-10-31'];v=[r['pe'] for r in rows if r['pe'] is not None]
 def q(p):
  a=sorted(v);h=(len(a)-1)*p;i=int(h);return a[i]+(a[min(i+1,len(a)-1)]-a[i])*(h-i)
 out['annualStats'].append({'years':y,'N':len(v),'negativeExcluded':len(rows)-len(v),'percentile':100*sum(a<=35.77 for a in v)/len(v),'median':statistics.median(v),'p20':q(.2),'p80':q(.8)})
sources=json.loads((P/'sources.json').read_text());sources.update({'diaHoldings':'https://www.ssga.com/library-content/products/fund-data/etfs/us/holdings-daily-us-en-dia.xlsx','vanguardFees':'https://corporate.vanguard.com/content/dam/corp/articles/pdf/expense_ratio_reduction_jan2026.pdf','russellRules':'https://www.lseg.com/content/dam/ftse-russell/en_us/documents/ground-rules/russell-us-indexes-construction-and-methodology.pdf','reconstitution':'https://www.lseg.com/en/media-centre/press-releases/ftse-russell/2026/ftse-russell-begins-december-2026-semi-annual-russell-us-indexes-reconstitution','domesticDow':'https://www.howbuy.com/fund/info/dtl/5134005542833.htm'})
out['sources']=sources
(P/'extension-calculations.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
for k in ['funds','pairs','iwvSizeWeight','annualStats']:print(k,json.dumps(out[k],ensure_ascii=True))
