from pathlib import Path
from bs4 import BeautifulSoup
import requests,concurrent.futures,json
P=Path('work/global100/extension')
urls={'iwb':'https://www.ishares.com/us/products/239707/ishares-russell-1000-etf','iwm':'https://www.ishares.com/us/products/239710/ishares-russell-2000-etf','iwv':'https://www.ishares.com/us/products/239714/ishares-russell-3000-etf','dia':'https://www.ssga.com/us/en/intermediary/etfs/state-street-spdr-dow-jones-industrial-average-etf-trust-dia','siblis-r2000':'https://siblisresearch.com/data/russell-2000-pe-yield/','vtwo':'https://advisors.vanguard.com/investments/products/vtwo/vanguard-russell-2000-etf','vthr':'https://advisors.vanguard.com/investments/products/vthr/vanguard-russell-3000-etf','vone':'https://advisors.vanguard.com/investments/products/vone/vanguard-russell-1000-etf'}
def one(it):
 k,u=it
 try:
  r=requests.get(u,timeout=35);r.raise_for_status();(P/(k+'.html')).write_bytes(r.content);s=BeautifulSoup(r.content,'html.parser');(P/(k+'.txt')).write_text(s.get_text(' ',strip=True),encoding='utf-8')
  if k in ['iwb','iwm','iwv']:
   a=next((a for a in s.find_all('a',href=True) if 'latest-holdings.csv' in a['href']),None)
   if a:
    hu='https://www.ishares.com'+a['href'] if a['href'].startswith('/') else a['href'];h=requests.get(hu,timeout=35);h.raise_for_status();(P/(k+'-holdings.csv')).write_bytes(h.content)
  return(k,len(r.content))
 except Exception as e:return(k,str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
 for r in ex.map(one,urls.items()):print(r,flush=True)
(P/'sources.json').write_text(json.dumps(urls,indent=2),encoding='utf-8')
