from pathlib import Path
from bs4 import BeautifulSoup
import requests,concurrent.futures
P=Path('work/global100/extension')
urls={'dia-holdings':'https://www.ssga.com/library-content/products/fund-data/etfs/us/holdings-daily-us-en-dia.xlsx','vanguard-list':'https://investor.vanguard.com/investment-products/list/etfs?filters=open&riskfilter=4','vtwo-sheet':'https://workplace.vanguard.com/assets/corp/fund_communications/pdf_publish/us-products/fact-sheet/F3351.pdf','vone-sheet':'https://workplace.vanguard.com/assets/corp/fund_communications/pdf_publish/us-products/fact-sheet/F3348.pdf','iwm-sheet':'https://www.blackrock.com/us/individual/literature/fact-sheet/iwm-ishares-russell-2000-etf-fund-fact-sheet-en-us.pdf'}
def one(it):
 k,u=it
 try:
  r=requests.get(u,timeout=30);r.raise_for_status();ext='xlsx' if k=='dia-holdings' else 'pdf' if k.endswith('sheet') else 'html';(P/(k+'.'+ext)).write_bytes(r.content);return(k,len(r.content))
 except Exception as e:return(k,str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
 for v in ex.map(one,urls.items()):print(v,flush=True)
